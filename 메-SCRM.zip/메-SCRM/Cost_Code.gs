/* =====================================================================
 * Cost_Code.gs  ·  메-SCRM 원가 / 시황 대시보드 백엔드
 * 공용 로직 → 통합_common.gs   ·   데이터/스코어링 → SCRM_score.gs (SCRM_getCost)
 * ===================================================================== */

var SCRM_PORTAL_URL = '__PORTAL_WEBAPP_URL__';

function doGet(e) {
  var t = HtmlService.createTemplateFromFile('index');
  t.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  t.portalUrl = SCRM_PORTAL_URL;
  return t.evaluate()
    .setTitle('메-SCRM · 원가 / 시황')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function Cost_reload() { SCRM_clearCache(); return SCRM_getCost(); }
