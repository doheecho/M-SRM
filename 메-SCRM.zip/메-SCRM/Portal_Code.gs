/* =====================================================================
 * Portal_Code.gs  ·  메-SCRM 통합 포털(랜딩) 백엔드
 * ---------------------------------------------------------------------
 * 공용 로직(include / getUserDetails / fetchUserDeptAndName /
 * checkUserFullAccess / logAccess / getMenuLinks)  →  통합_common.gs
 * 데이터/스코어링(SCRM_getPortal / SCRM_getSupplier)  →  SCRM_score.gs
 *
 * 이 파일은 포털 고유의 doGet + 대시보드 링크 설정만 담는다.
 * ===================================================================== */

/** 4개 하위 대시보드 웹앱 URL — 배포 후 실제 exec URL 로 교체
 *  (값이 '__' 로 시작하면 포털 카드가 "준비중" 비활성으로 표시된다) */
var SCRM_DASHBOARD_URLS = {
  riskmap:  '__RISKMAP_WEBAPP_URL__',   // 지정학 리스크 (SCM Map)
  cost:     '__COST_WEBAPP_URL__',      // 원가 / 시황
  delivery: '__DELIVERY_WEBAPP_URL__',  // 조달 / 납기
  finance:  '__FINANCE_WEBAPP_URL__'    // 경영악화
};

function doGet(e) {
  var t = HtmlService.createTemplateFromFile('index');
  t.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  t.dashboardUrls = JSON.stringify(SCRM_DASHBOARD_URLS);
  return t.evaluate()
    .setTitle('메-SCRM · 공급망 리스크 포털')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** 프론트에서 새로고침 버튼으로 캐시 비우고 재조회 */
function SCRM_reloadPortal() {
  SCRM_clearCache();
  return SCRM_getPortal();
}
