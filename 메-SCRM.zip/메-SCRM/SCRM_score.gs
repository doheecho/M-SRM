/* =====================================================================
 * SCRM_score.gs  ·  메-SCRM 공용 데이터 접근 + 공급망 리스크 스코어링 엔진
 * ---------------------------------------------------------------------
 * 목적 : 통합 포털 / 지정학(RiskMap) / 원가·시황(Cost) / 조달·납기(Delivery) /
 *        경영악화(Finance) 모든 모듈이 "동일한 협력사 리스크 점수"를 쓰도록
 *        단일 소스로 통합.
 *
 * 스코어링 요지 (자세히는 docs/스코어링_상세.md)
 *   축점수(0~100) = 100 · T · (0.5 + 0.25·E + 0.25·V)
 *     E 노출도  = 0.5·거래액백분위 + 0.5·소싱계수
 *     V 취약성  = 0.5·대체난이도 + 0.5·재고부족도
 *     T 위협도  = max( 이벤트기반 T , 축별 지표기반 T )
 *        - 지정학 : 매칭된 리스크이벤트의 max(심각도)/4
 *        - 원가   : 원자재/환율/운임 지수 변동률 + 인상요청 시황역행
 *        - 조달   : OTD 저하 + 리드타임 증가 + 결품 임박 + 반복 지연
 *        - 경영   : 재무비율 악화 + 조기경보 플래그
 *   통합점수 = 4개 축점수의 최댓값
 *   등급     = 0 안정 / 1 관심(≥1) / 2 주의(≥25) / 3 경계(≥50) / 4 심각(≥75)
 *
 * 데이터 : 별도 구글시트 "메-SCRM DB" (수기 업로드). 탭 정의 → _스프레드시트_스키마.md
 *   협력사마스터 · 리스크이벤트 · 품목원산지 · 시나리오
 *   시황지수 · 원가요청 · 납기실적 · 협력사재무
 *
 * 배포 : 이 파일은 메-SCRM 의 모든 모듈 GAS 프로젝트에 "동일 파일"로 복사한다.
 *        통합_common.gs 의 SRM_readSheet_ / SRM_safe_ / SRM_getUserContext_ 에 의존.
 * ===================================================================== */

/** 메-SCRM 전용 데이터 스프레드시트 ID — 배포 시 실제 ID 로 교체 */
var SCRM_DB_SS_ID = '__PUT_메-SCRM_DB_SPREADSHEET_ID_HERE__';

/** 4대 리스크 축 (모든 모듈 공통 순서) */
var SCRM_AXES = ['지정학', '원가', '조달', '경영'];

/** 등급 임계 (축점수 0~100 → 0 안정 / 1 관심 / 2 주의 / 3 경계 / 4 심각) */
var SCRM_GRADE_CUTS = [0.01, 25, 50, 75];
var SCRM_GRADE_LABEL = ['안정', '관심', '주의', '경계', '심각'];

/** 이벤트 좌표가 없을 때 "영향지역" 국가코드 → 대략적 중심좌표 (지도 라벨용) */
var SCRM_COUNTRY_CENTROID = {
  KR:[36.5,127.9], CN:[35.9,104.2], JP:[36.2,138.3], TW:[23.7,121.0], US:[39.8,-98.6],
  VN:[16.0,107.8], MY:[4.2,101.9], PH:[12.9,121.8], IN:[22.0,79.0], ID:[-2.5,118.0],
  TH:[15.0,101.0], SG:[1.35,103.8], DE:[51.1,10.4], FR:[46.6,2.4], IT:[42.8,12.6],
  GB:[54.0,-2.0], CA:[56.1,-106.3], MX:[23.6,-102.5], IL:[31.4,35.0], IR:[32.4,53.7],
  SA:[24.0,45.0], AE:[24.0,54.0], RU:[61.5,105.3], UA:[48.4,31.2], AU:[-25.3,133.8],
  BR:[-14.2,-51.9], NL:[52.1,5.3], EG:[26.8,30.8], CL:[-35.7,-71.5], CD:[-4.0,21.8]
};

var SCRM_CATEGORY_COLOR = {
  '지정학':'#DC3545', '원가':'#F5A623', '조달':'#0D6EFD', '경영':'#6f42c1'
};

/** 핵심광물 키워드 (지정학 KPI · 품목원산지 집계) */
var SCRM_MINERAL_RE = /갈륨|게르마늄|안티모니|흑연|희토류|네오디뮴|디스프로슘|텅스텐|리튬|코발트|형석|마그네슘/;

/** 조기경보 "중대" 플래그 — 발견 즉시 경영 T 를 0.85 로 끌어올림 */
var SCRM_SEVERE_FLAG_RE = /어음부도|부도|임금체불|법정관리|회생|파산|가압류/;

/* 요청 단위 메모리 캐시 */
var SCRM__memo = {};

/* ---------------------------------------------------------------------
 * 0. 파싱 헬퍼
 * ------------------------------------------------------------------- */
function SCRM_num_(v) {
  if (v == null || v === '') return 0;
  var n = parseFloat(String(v).replace(/[, %]/g, ''));
  return isFinite(n) ? n : 0;
}
function SCRM_list_(v) {
  if (v == null || v === '') return [];
  return String(v).split(/[,;#\/]+/).map(function (s) { return s.trim(); }).filter(Boolean);
}
function SCRM_clamp_(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
function SCRM_grade_(score) {
  for (var g = 4; g >= 1; g--) if (score >= SCRM_GRADE_CUTS[g - 1]) return g;
  return 0;
}
function SCRM_groupsMatch_(a, b) {
  if (!a || !b) return false;
  return a.indexOf(b) !== -1 || b.indexOf(a) !== -1;
}

/* ---------------------------------------------------------------------
 * 1. 원천 데이터 로드 (SRM_readSheet_ 캐시 → 객체 배열)
 *    시트/스프레드시트가 없거나 비면 내장 샘플로 폴백해 화면이 항상 뜨게 한다.
 * ------------------------------------------------------------------- */
function SCRM_loadRaw_() {
  if (SCRM__memo.raw) return SCRM__memo.raw;

  var out = { suppliers: [], events: [], origins: [], scenarios: [],
              indices: [], costReqs: [], delivery: [], finance: [], source: 'sheet' };
  var get = function (name, ttl) {
    return SRM_safe_(function () {
      return SRM_toObjects_(SRM_readSheet_(name, { id: SCRM_DB_SS_ID, ttl: ttl || 1800 }));
    }, []);
  };
  var ok = SRM_safe_(function () {
    out.suppliers = SRM_toObjects_(SRM_readSheet_('협력사마스터', { id: SCRM_DB_SS_ID, ttl: 1800 }));
    out.events    = SRM_toObjects_(SRM_readSheet_('리스크이벤트', { id: SCRM_DB_SS_ID, ttl: 900 }));
    return true;
  }, false);

  if (!ok || !out.suppliers.length) {
    var s = SCRM_sampleData_();
    s.source = 'sample';
    SCRM__memo.raw = s;
    return s;
  }

  out.origins   = get('품목원산지', 1800);
  out.scenarios = get('시나리오', 1800);
  out.indices   = get('시황지수', 900);
  out.costReqs  = get('원가요청', 900);
  out.delivery  = get('납기실적', 900);
  out.finance   = get('협력사재무', 1800);
  SCRM__memo.raw = out;
  return out;
}

/** 프론트 캐시 무효화용 */
function SCRM_clearCache() {
  SCRM__memo = {};
  ['협력사마스터', '리스크이벤트', '품목원산지', '시나리오',
   '시황지수', '원가요청', '납기실적', '협력사재무'].forEach(function (n) {
    SRM_safe_(function () { SRM_clearSheetCache_(n, SCRM_DB_SS_ID); }, null);
  });
  return { success: true };
}

/* ---------------------------------------------------------------------
 * 2. 정규화된 도메인 모델
 * ------------------------------------------------------------------- */
function SCRM_model_() {
  if (SCRM__memo.model) return SCRM__memo.model;
  var raw = SCRM_loadRaw_();

  var suppliers = raw.suppliers.map(function (r) {
    return {
      code: String(r['협력사코드'] || '').trim(),
      name: String(r['협력사명'] || '').trim(),
      country: String(r['국가'] || '').trim().toUpperCase(),
      city: String(r['도시'] || '').trim(),
      lat: SCRM_num_(r['위도']), lon: SCRM_num_(r['경도']),
      itemGroup: String(r['품목군'] || '').trim(),
      item: String(r['주력품목'] || '').trim(),
      spend: SCRM_num_(r['연간거래액(백만원)'] || r['연간거래액']),
      sourcing: String(r['소싱유형'] || '').trim(),
      altEase: String(r['대체가능성'] || '').trim(),
      altMonths: SCRM_num_(r['대체소요기간(개월)'] || r['대체소요기간']),
      stockDays: SCRM_num_(r['재고커버리지(일)'] || r['재고커버리지']),
      md: String(r['담당MD'] || '').trim(),
      note: String(r['비고'] || '').trim()
    };
  }).filter(function (s) { return s.code; });

  var events = raw.events.map(function (r, i) {
    return {
      id: String(r['이벤트ID'] || ('E' + (i + 1))).trim(),
      category: String(r['카테고리'] || '지정학').trim(),
      subtype: String(r['세부유형'] || '').trim(),
      title: String(r['제목'] || '').trim(),
      date: String(r['발생일'] || '').trim(),
      severity: Math.max(1, Math.min(4, SCRM_num_(r['심각도']) || 1)),
      status: String(r['진행상태'] || '진행').trim(),
      regions: SCRM_list_(r['영향지역']).map(function (x) { return x.toUpperCase(); }),
      itemGroups: SCRM_list_(r['영향품목군']),
      supplierCodes: SCRM_list_(r['영향협력사코드']),
      lat: SCRM_num_(r['지도위도'] || r['지도표시위도']),
      lon: SCRM_num_(r['지도경도'] || r['지도표시경도']),
      radiusKm: SCRM_num_(r['영향반경km']),
      plan: String(r['대응계획'] || '').trim(),
      planStatus: String(r['대응상태'] || '').trim(),
      url: String(r['출처URL'] || '').trim()
    };
  }).filter(function (e) { return e.title; });

  var originsBySupplier = {};
  (raw.origins || []).forEach(function (r) {
    var code = String(r['협력사코드'] || '').trim();
    if (!code) return;
    (originsBySupplier[code] = originsBySupplier[code] || []).push({
      item: String(r['품목'] || '').trim(),
      material: String(r['투입원자재'] || '').trim(),
      originCountry: String(r['원산지국가'] || '').trim().toUpperCase(),
      dependency: SCRM_num_(r['원산지의존도(%)'] || r['원산지의존도'])
    });
  });

  var scenarios = (raw.scenarios || []).map(function (r) {
    return {
      id: String(r['시나리오ID'] || '').trim(),
      name: String(r['시나리오명'] || '').trim(),
      eventIds: SCRM_list_(r['포함이벤트ID']),
      regions: SCRM_list_(r['영향지역']).map(function (x) { return x.toUpperCase(); }),
      itemGroups: SCRM_list_(r['영향품목군']),
      desc: String(r['설명'] || '').trim()
    };
  }).filter(function (s) { return s.name; });

  /* ---- 원가 : 시황지수 ---- */
  var indices = (raw.indices || []).map(function (r) {
    var latest = SCRM_num_(r['최신값']), prev = SCRM_num_(r['3개월전값']);
    var chg = SCRM_num_(r['3개월변동률(%)'] || r['3개월변동률']);
    if (!chg && prev) chg = Math.round((latest / prev - 1) * 1000) / 10;
    return {
      name: String(r['지수명'] || '').trim(),
      kind: String(r['구분'] || '').trim(),          // 원자재 / 환율 / 운임
      latest: latest, prev: prev, chgPct: chg,
      itemGroups: SCRM_list_(r['연결품목군']),
      note: String(r['비고'] || '').trim()
    };
  }).filter(function (x) { return x.name; });

  var costReqBySupplier = {};
  (raw.costReqs || []).forEach(function (r) {
    var code = String(r['협력사코드'] || '').trim();
    if (!code) return;
    (costReqBySupplier[code] = costReqBySupplier[code] || []).push({
      date: String(r['요청일'] || '').trim(),
      rate: SCRM_num_(r['요청률(%)'] || r['요청률']),
      reason: String(r['사유'] || '').trim(),
      status: String(r['상태'] || '검토').trim()
    });
  });

  /* ---- 조달 : 납기실적 (협력사별 월 배열, 최신월 우선) ---- */
  var deliveryBySupplier = {};
  (raw.delivery || []).forEach(function (r) {
    var code = String(r['협력사코드'] || '').trim();
    if (!code) return;
    (deliveryBySupplier[code] = deliveryBySupplier[code] || []).push({
      month: String(r['기준월'] || '').trim(),
      otd: SCRM_num_(r['OTD(%)'] || r['OTD']),
      ltNow: SCRM_num_(r['평균리드타임_현재(일)'] || r['평균리드타임_현재']),
      ltPrev: SCRM_num_(r['평균리드타임_3개월전(일)'] || r['평균리드타임_3개월전']),
      backorders: SCRM_num_(r['미입고건수']),
      delayCount: SCRM_num_(r['지연횟수_최근3개월'] || r['지연횟수']),
      reason: String(r['주요지연사유'] || '').trim()
    });
  });
  Object.keys(deliveryBySupplier).forEach(function (c) {
    deliveryBySupplier[c].sort(function (a, b) { return String(b.month).localeCompare(String(a.month)); });
  });

  /* ---- 경영 : 협력사재무 (분기별, 최신분기 우선) ---- */
  var financeBySupplier = {};
  (raw.finance || []).forEach(function (r) {
    var code = String(r['협력사코드'] || '').trim();
    if (!code) return;
    (financeBySupplier[code] = financeBySupplier[code] || []).push({
      quarter: String(r['기준분기'] || '').trim(),
      debtRatio: SCRM_num_(r['부채비율(%)'] || r['부채비율']),
      currentRatio: SCRM_num_(r['유동비율(%)'] || r['유동비율']),
      opMargin: SCRM_num_(r['영업이익률(%)'] || r['영업이익률']),
      iscr: SCRM_num_(r['이자보상배율']),
      grade: String(r['신용등급'] || '').trim(),
      dependency: SCRM_num_(r['당사매출의존도(%)'] || r['당사매출의존도']),
      flags: SCRM_list_(r['조기경보플래그']),
      note: String(r['비고'] || '').trim()
    });
  });
  Object.keys(financeBySupplier).forEach(function (c) {
    financeBySupplier[c].sort(function (a, b) { return String(b.quarter).localeCompare(String(a.quarter)); });
  });

  SCRM__memo.model = {
    suppliers: suppliers, events: events,
    originsBySupplier: originsBySupplier, scenarios: scenarios,
    indices: indices, costReqBySupplier: costReqBySupplier,
    deliveryBySupplier: deliveryBySupplier, financeBySupplier: financeBySupplier,
    source: raw.source
  };
  return SCRM__memo.model;
}

/* ---------------------------------------------------------------------
 * 3. 이벤트 ↔ 협력사 매칭 (지정학 축)
 * ------------------------------------------------------------------- */
function SCRM_eventHitsSupplier_(ev, sup, originList) {
  if (ev.supplierCodes.length && ev.supplierCodes.indexOf(sup.code) !== -1) return true;

  var regionHit = false;
  if (ev.regions.length) {
    if (ev.regions.indexOf('전세계') !== -1 || ev.regions.indexOf('GLOBAL') !== -1) regionHit = true;
    else if (ev.regions.indexOf(sup.country) !== -1) regionHit = true;
    else if (ev.category === '지정학' && originList && originList.length) {
      regionHit = originList.some(function (o) { return ev.regions.indexOf(o.originCountry) !== -1; });
    }
  }
  if (!regionHit) return false;
  if (!ev.itemGroups.length) return true;
  return ev.itemGroups.some(function (g) { return SCRM_groupsMatch_(sup.itemGroup, g); });
}

/* ---------------------------------------------------------------------
 * 4. 스코어링
 * ------------------------------------------------------------------- */
function SCRM_sourcingCoef_(s) {
  if (/단일|single|sole/i.test(s)) return 1.0;
  if (/이원|dual/i.test(s)) return 0.5;
  if (/다원|multi/i.test(s)) return 0.2;
  return 0.6;
}
function SCRM_altCoef_(s) {
  if (/하|low|hard|어려/i.test(s)) return 1.0;
  if (/중|mid|medium/i.test(s)) return 0.6;
  if (/상|high|easy|쉬/i.test(s)) return 0.3;
  return 0.7;
}

/** 협력사 품목군에 연결된 시황지수들의 평균 변동률
 *  kindFilter 지정 시 해당 구분(원자재/환율/운임)만 집계.
 *  연결품목군이 빈 지수(환율·운임 등)는 kindFilter 없을 때만 전 협력사 공통 적용. */
function SCRM_indexChgForGroup_(indices, itemGroup, kindFilter) {
  var vals = [];
  indices.forEach(function (ix) {
    if (kindFilter && ix.kind !== kindFilter) return;
    var linked = ix.itemGroups.length
      ? (itemGroup && ix.itemGroups.some(function (g) { return SCRM_groupsMatch_(itemGroup, g); }))
      : !kindFilter;   // 연결품목군 없는 지수는 종합(kindFilter 없음)일 때만 포함
    if (linked) vals.push(ix.chgPct);
  });
  if (!vals.length) return 0;
  return vals.reduce(function (a, b) { return a + b; }, 0) / vals.length;
}

/** 원가 지표기반 T
 *  idxChg : 원자재+환율+운임 종합 변동률 (T 산출용 — 전 비용동인 반영)
 *  matChg : 원자재 지수만의 변동률 (인상요청 역행 판정용 — 매크로 동인 제외) */
function SCRM_costT_(sup, model) {
  var idxChg = SCRM_indexChgForGroup_(model.indices, sup.itemGroup);
  var matChg = SCRM_indexChgForGroup_(model.indices, sup.itemGroup, '원자재');
  var idxRisk = SCRM_clamp_(idxChg / 30, 0, 1);                 // 종합 +30% = 만점
  var reqs = model.costReqBySupplier[sup.code] || [];
  var reqRate = 0;
  reqs.forEach(function (q) { if (q.status !== '반려' && q.rate > reqRate) reqRate = q.rate; });
  // 원자재 시황 대비 5%p 이상 과도한 인상요청 → 역행 리스크
  var reqDiv = reqRate > 0 ? SCRM_clamp_((reqRate - Math.max(matChg, 0) - 5) / 20, 0, 1) : 0;
  return { T: SCRM_clamp_(0.7 * idxRisk + 0.3 * reqDiv, 0, 1),
           idxChg: idxChg, matChg: matChg, reqRate: reqRate, divergent: reqDiv > 0 };
}

/** 조달 지표기반 T */
function SCRM_deliveryT_(sup, model) {
  var arr = model.deliveryBySupplier[sup.code] || [];
  if (!arr.length) return { T: 0 };
  var d = arr[0];
  var otdRisk = SCRM_clamp_((95 - d.otd) / 40, 0, 1);           // OTD 95%→0, 55%→만점
  var ltRisk = d.ltPrev > 0 ? SCRM_clamp_((d.ltNow / d.ltPrev - 1) / 0.4, 0, 1) : 0;  // +40% → 만점
  var stockout = d.ltNow > 0 ? SCRM_clamp_(1 - sup.stockDays / (d.ltNow * 1.5), 0, 1) : 0;
  var repeat = SCRM_clamp_(d.delayCount / 3, 0, 1);
  var T = SCRM_clamp_(0.35 * otdRisk + 0.25 * ltRisk + 0.25 * stockout + 0.15 * repeat, 0, 1);
  return { T: T, otd: d.otd, ltNow: d.ltNow, ltPrev: d.ltPrev, ltInc: d.ltPrev > 0 ? (d.ltNow / d.ltPrev - 1) : 0,
           stockoutRisk: stockout, delayCount: d.delayCount, month: d.month, reason: d.reason };
}

/** 경영 지표기반 T */
function SCRM_financeT_(sup, model) {
  var arr = model.financeBySupplier[sup.code] || [];
  if (!arr.length) return { T: 0 };
  var f = arr[0];
  var debtRisk = SCRM_clamp_((f.debtRatio - 150) / 250, 0, 1);       // 150%→0, 400%→만점
  var liqRisk = SCRM_clamp_((120 - f.currentRatio) / 70, 0, 1);      // 120%→0, 50%→만점
  var iscrRisk = f.iscr > 0 ? (f.iscr < 1 ? 1 : SCRM_clamp_((3 - f.iscr) / 2.5, 0, 1)) : 0.5;
  var opmRisk = SCRM_clamp_((3 - f.opMargin) / 8, 0, 1);            // 3%→0, -5%→만점
  var base = 0.3 * debtRisk + 0.2 * liqRisk + 0.25 * iscrRisk + 0.25 * opmRisk;
  var flagRisk = SCRM_clamp_(f.flags.length / 3, 0, 1);
  var severe = f.flags.some(function (x) { return SCRM_SEVERE_FLAG_RE.test(x); });
  var T = SCRM_clamp_(Math.max(0.6 * base + 0.4 * flagRisk, severe ? 0.85 : 0), 0, 1);
  return { T: T, debtRatio: f.debtRatio, currentRatio: f.currentRatio, opMargin: f.opMargin,
           iscr: f.iscr, grade: f.grade, dependency: f.dependency, flags: f.flags,
           quarter: f.quarter, severe: severe,
           metricRisk: { debt: debtRisk, liq: liqRisk, iscr: iscrRisk, opm: opmRisk } };
}

function SCRM_computeScores_(opts) {
  opts = opts || {};
  var m = SCRM_model_();
  var maxSpend = 1;
  m.suppliers.forEach(function (s) { if (s.spend > maxSpend) maxSpend = s.spend; });

  var extraRegions = (opts.scenarioRegions || []).map(function (x) { return String(x).toUpperCase(); });
  var extraGroups = opts.scenarioGroups || [];
  var useScenario = extraRegions.length || extraGroups.length;

  var rows = m.suppliers.map(function (sup) {
    var origins = m.originsBySupplier[sup.code] || [];
    var E = 0.5 * Math.min(1, sup.spend / maxSpend) + 0.5 * SCRM_sourcingCoef_(sup.sourcing);
    var stockShortfall = 1;
    if (sup.altMonths > 0) stockShortfall = SCRM_clamp_(1 - sup.stockDays / (sup.altMonths * 30), 0, 1);
    else if (sup.stockDays > 0) stockShortfall = 0.3;
    var V = 0.5 * SCRM_altCoef_(sup.altEase) + 0.5 * stockShortfall;

    /* --- 이벤트기반 T (축별 max 심각도) --- */
    var evT = {}, axisEvents = {};
    SCRM_AXES.forEach(function (a) { evT[a] = 0; axisEvents[a] = []; });
    m.events.forEach(function (ev) {
      if (ev.status === '종결') return;
      if (ev.category === '지정학') {
        // 지정학 : 지역/원산지/품목군 매칭 + 영향협력사코드는 화이트리스트로 "추가"
        if (!SCRM_eventHitsSupplier_(ev, sup, origins)) return;
      } else {
        // 원가/조달/경영 : 특정성 우선 — 협력사코드 지정 시 그 목록만, 없으면 품목군, 그것도 없으면 국가
        var hit;
        if (ev.supplierCodes.length) hit = ev.supplierCodes.indexOf(sup.code) !== -1;
        else if (ev.itemGroups.length) hit = ev.itemGroups.some(function (g) { return SCRM_groupsMatch_(sup.itemGroup, g); });
        else hit = ev.regions.indexOf(sup.country) !== -1;
        if (!hit) return;
      }
      var t = (ev.severity / 4) * (ev.status === '완화' ? 0.6 : 1);
      axisEvents[ev.category] = axisEvents[ev.category] || [];
      axisEvents[ev.category].push(ev.id);
      if (t > (evT[ev.category] || 0)) evT[ev.category] = t;
    });

    /* --- what-if 시나리오 (지정학, 심각도 4 가정) --- */
    if (useScenario) {
      var scHit = (extraRegions.indexOf(sup.country) !== -1) ||
        origins.some(function (o) { return extraRegions.indexOf(o.originCountry) !== -1; });
      if (scHit && (!extraGroups.length || extraGroups.some(function (g) { return SCRM_groupsMatch_(sup.itemGroup, g); }))) {
        evT['지정학'] = Math.max(evT['지정학'], 1);
        axisEvents['지정학'].push('SCENARIO');
      }
    }

    /* --- 지표기반 T (축별) --- */
    var cost = SCRM_costT_(sup, m);
    var deliv = SCRM_deliveryT_(sup, m);
    var fin = SCRM_financeT_(sup, m);
    var metricT = { '지정학': 0, '원가': cost.T, '조달': deliv.T, '경영': fin.T };

    var scores = {}, grades = {}, axisT = {}, axisSource = {};
    SCRM_AXES.forEach(function (a) {
      var t = Math.max(evT[a], metricT[a]);
      axisT[a] = Math.round(t * 100) / 100;
      axisSource[a] = (metricT[a] >= evT[a] && metricT[a] > 0) ? 'metric' : (evT[a] > 0 ? 'event' : '-');
      var sc = 100 * t * (0.5 + 0.25 * E + 0.25 * V);
      scores[a] = Math.round(sc * 10) / 10;
      grades[a] = SCRM_grade_(scores[a]);
    });
    var total = Math.max(scores['지정학'], scores['원가'], scores['조달'], scores['경영']);

    return {
      code: sup.code, name: sup.name, country: sup.country, city: sup.city,
      lat: sup.lat, lon: sup.lon, itemGroup: sup.itemGroup, item: sup.item,
      spend: sup.spend, sourcing: sup.sourcing, md: sup.md,
      isSingle: SCRM_sourcingCoef_(sup.sourcing) >= 1.0,
      exposure: Math.round(E * 100) / 100, vulnerability: Math.round(V * 100) / 100,
      scores: scores, grades: grades, axisT: axisT, axisSource: axisSource,
      totalScore: Math.round(total * 10) / 10, totalGrade: SCRM_grade_(total),
      axisEvents: axisEvents, origins: origins,
      cost: cost, deliv: deliv, fin: fin
    };
  });

  return rows;
}

/* ---------------------------------------------------------------------
 * 5. 프론트 공용 API
 * ------------------------------------------------------------------- */

function SCRM_getPortal() {
  return SRM_safe_(function () {
    var ctx = SRM_getUserContext_();
    var m = SCRM_model_();
    var rows = SCRM_computeScores_();

    var totalSpend = 0, atRiskSpend = 0, priorityCount = 0;
    rows.forEach(function (r) {
      totalSpend += r.spend;
      if (r.totalGrade >= 3) atRiskSpend += r.spend;
      if (r.isSingle && r.totalGrade >= 4) priorityCount++;
    });

    var idxNum = 0, idxDen = 0;
    rows.forEach(function (r) { var w = r.spend || 1; idxNum += r.totalScore * w; idxDen += w; });
    var scrmIndex = idxDen ? Math.round((idxNum / idxDen) * 10) / 10 : 0;

    var axisSummary = SCRM_AXES.map(function (a) {
      var c = { axis: a, 심각: 0, 경계: 0, 주의: 0, 관심: 0 };
      rows.forEach(function (r) {
        var g = r.grades[a];
        if (g === 4) c['심각']++; else if (g === 3) c['경계']++;
        else if (g === 2) c['주의']++; else if (g === 1) c['관심']++;
      });
      return c;
    });

    var top = rows.slice().sort(function (a, b) { return b.totalScore - a.totalScore; }).slice(0, 10)
      .map(function (r) {
        return { code: r.code, name: r.name, country: r.country, itemGroup: r.itemGroup,
          spend: r.spend, sourcing: r.sourcing, md: r.md, scores: r.scores, grades: r.grades,
          totalScore: r.totalScore, totalGrade: r.totalGrade };
      });

    var heat = rows.filter(function (r) { return r.totalGrade >= 1; })
      .sort(function (a, b) { return b.totalScore - a.totalScore; }).slice(0, 40)
      .map(function (r) {
        return { code: r.code, name: r.name, country: r.country, spend: r.spend,
          grades: r.grades, scores: r.scores, totalGrade: r.totalGrade };
      });

    var feed = m.events.slice().sort(function (a, b) { return String(b.date).localeCompare(String(a.date)); })
      .slice(0, 15).map(function (e) {
        return { id: e.id, category: e.category, subtype: e.subtype, title: e.title,
          date: e.date, severity: e.severity, status: e.status, regions: e.regions, itemGroups: e.itemGroups };
      });

    return {
      success: true, source: m.source,
      user: { email: ctx.email, id: ctx.id, name: ctx.name, dept: ctx.dept },
      displayName: (ctx.dept && ctx.name) ? (ctx.dept + ' ' + ctx.name) : (ctx.name || 'USER'),
      menu: getMenuLinks(),
      kpi: {
        scrmIndex: scrmIndex, supplierCount: rows.length, priorityCount: priorityCount,
        activeEvents: m.events.filter(function (e) { return e.status !== '종결'; }).length,
        atRiskSpend: Math.round(atRiskSpend), totalSpend: Math.round(totalSpend)
      },
      axes: SCRM_AXES, axisColor: SCRM_CATEGORY_COLOR, axisSummary: axisSummary,
      top: top, heat: heat, feed: feed, gradeLabel: SCRM_GRADE_LABEL
    };
  }, { success: false, message: '포털 데이터 로드 실패' });
}

function SCRM_getSupplier(code) {
  return SRM_safe_(function () {
    var rows = SCRM_computeScores_();
    var r = rows.filter(function (x) { return x.code === code; })[0];
    if (!r) return { success: false, message: '협력사를 찾을 수 없습니다: ' + code };
    var m = SCRM_model_();
    var evs = [];
    SCRM_AXES.forEach(function (a) {
      (r.axisEvents[a] || []).forEach(function (id) {
        var e = m.events.filter(function (x) { return x.id === id; })[0];
        if (e) evs.push({ id: e.id, category: e.category, title: e.title, date: e.date,
          severity: e.severity, status: e.status, plan: e.plan, planStatus: e.planStatus });
      });
    });
    return { success: true, supplier: r, events: evs, gradeLabel: SCRM_GRADE_LABEL };
  }, { success: false, message: '조회 실패' });
}

function SCRM_getRiskMap(params) {
  return SRM_safe_(function () {
    params = params || {};
    var m = SCRM_model_();
    var rows = SCRM_computeScores_({
      scenarioRegions: params.scenarioRegions || [], scenarioGroups: params.scenarioGroups || []
    });

    var suppliers = rows.map(function (r) {
      return { code: r.code, name: r.name, country: r.country, city: r.city, lat: r.lat, lon: r.lon,
        itemGroup: r.itemGroup, item: r.item, spend: r.spend, sourcing: r.sourcing, md: r.md, isSingle: r.isSingle,
        geoScore: r.scores['지정학'], geoGrade: r.grades['지정학'], totalScore: r.totalScore, totalGrade: r.totalGrade,
        hitEvents: (r.axisEvents['지정학'] || []), origins: r.origins };
    });

    var events = m.events.filter(function (e) { return e.category === '지정학'; }).map(function (e) {
      var ll = (e.lat && e.lon) ? [e.lat, e.lon]
        : (e.regions.length && SCRM_COUNTRY_CENTROID[e.regions[0]]) ? SCRM_COUNTRY_CENTROID[e.regions[0]] : null;
      return { id: e.id, subtype: e.subtype, title: e.title, date: e.date, severity: e.severity, status: e.status,
        regions: e.regions, itemGroups: e.itemGroups, supplierCodes: e.supplierCodes,
        lat: ll ? ll[0] : null, lon: ll ? ll[1] : null, radiusKm: e.radiusKm,
        plan: e.plan, planStatus: e.planStatus, url: e.url };
    });

    var hitBySup = {};
    rows.forEach(function (r) { (r.axisEvents['지정학'] || []).forEach(function (id) {
      (hitBySup[id] = hitBySup[id] || []).push(r.code); }); });
    events.forEach(function (e) { e.hitSuppliers = hitBySup[e.id] || []; });

    var mineralItems = 0;
    Object.keys(m.originsBySupplier).forEach(function (code) {
      m.originsBySupplier[code].forEach(function (o) { if (SCRM_MINERAL_RE.test(o.material)) mineralItems++; });
    });
    var highGeo = suppliers.filter(function (s) { return s.geoGrade >= 3; });
    var kpi = {
      highGeoCount: highGeo.length,
      singleHighCount: highGeo.filter(function (s) { return s.isSingle; }).length,
      mineralItemCount: mineralItems,
      affectedSpend: Math.round(highGeo.reduce(function (a, s) { return a + s.spend; }, 0)),
      activeGeoEvents: events.filter(function (e) { return e.status !== '종결'; }).length
    };

    return { success: true, source: m.source, suppliers: suppliers, events: events, scenarios: m.scenarios,
      countryCentroid: SCRM_COUNTRY_CENTROID, kpi: kpi, gradeLabel: SCRM_GRADE_LABEL, menu: getMenuLinks() };
  }, { success: false, message: '지정학 데이터 로드 실패' });
}

/* ---------------------------------------------------------------------
 * 5-2. 원가 / 시황
 * ------------------------------------------------------------------- */
function SCRM_getCost() {
  return SRM_safe_(function () {
    var m = SCRM_model_();
    var rows = SCRM_computeScores_();

    var indices = m.indices.slice().sort(function (a, b) { return b.chgPct - a.chgPct; })
      .map(function (ix) { return { name: ix.name, kind: ix.kind, latest: ix.latest, chgPct: ix.chgPct,
        itemGroups: ix.itemGroups, spike: ix.chgPct >= 10 }; });

    // 품목군 × 연결지수 민감도
    var groups = {};
    m.suppliers.forEach(function (s) { if (s.itemGroup) groups[s.itemGroup] = true; });
    var sensitivity = Object.keys(groups).map(function (g) {
      var linked = m.indices.filter(function (ix) {
        return !ix.itemGroups.length ? (ix.kind === '환율' || ix.kind === '운임')
          : ix.itemGroups.some(function (x) { return SCRM_groupsMatch_(g, x); });
      });
      var chg = SCRM_indexChgForGroup_(m.indices, g);
      return { itemGroup: g, chgPct: Math.round(chg * 10) / 10,
        indices: linked.map(function (ix) { return { name: ix.name, chgPct: ix.chgPct }; }),
        grade: SCRM_grade_(SCRM_clamp_(chg / 30, 0, 1) * 100) };
    }).sort(function (a, b) { return b.chgPct - a.chgPct; });

    // 인상요청 vs 시황 (역행 판정은 원자재 지수 기준)
    var requests = [];
    rows.forEach(function (r) {
      var reqs = m.costReqBySupplier[r.code] || [];
      reqs.forEach(function (q) {
        requests.push({ code: r.code, name: r.name, itemGroup: r.itemGroup,
          date: q.date, rate: q.rate, status: q.status, reason: q.reason,
          matChg: Math.round(r.cost.matChg * 10) / 10,
          idxChg: Math.round(r.cost.idxChg * 10) / 10,
          divergent: q.status !== '반려' && q.rate > 0 && q.rate - Math.max(r.cost.matChg, 0) > 5 });
      });
    });
    requests.sort(function (a, b) { return (b.rate - b.matChg) - (a.rate - a.matChg); });

    var riskRows = rows.filter(function (r) { return r.grades['원가'] >= 1; })
      .sort(function (a, b) { return b.scores['원가'] - a.scores['원가']; })
      .map(function (r) { return { code: r.code, name: r.name, country: r.country, itemGroup: r.itemGroup,
        spend: r.spend, sourcing: r.sourcing, md: r.md,
        idxChg: Math.round(r.cost.idxChg * 10) / 10, matChg: Math.round(r.cost.matChg * 10) / 10,
        reqRate: r.cost.reqRate, divergent: r.cost.divergent, score: r.scores['원가'], grade: r.grades['원가'],
        source: r.axisSource['원가'], totalScore: r.totalScore, totalGrade: r.totalGrade }; });

    var riskAmt = 0;
    rows.forEach(function (r) { if (r.grades['원가'] >= 2) riskAmt += r.spend * r.scores['원가'] / 100; });

    return {
      success: true, source: m.source, menu: getMenuLinks(), gradeLabel: SCRM_GRADE_LABEL,
      indices: indices, sensitivity: sensitivity, requests: requests, riskRows: riskRows,
      kpi: {
        riskAmount: Math.round(riskAmt),
        divergentCount: requests.filter(function (x) { return x.divergent; }).length,
        spikeCount: indices.filter(function (x) { return x.spike; }).length,
        highCount: rows.filter(function (r) { return r.grades['원가'] >= 3; }).length
      }
    };
  }, { success: false, message: '원가 데이터 로드 실패' });
}

/* ---------------------------------------------------------------------
 * 5-3. 조달 / 납기
 * ------------------------------------------------------------------- */
function SCRM_getDelivery() {
  return SRM_safe_(function () {
    var m = SCRM_model_();
    var rows = SCRM_computeScores_();

    // 협력사 × 월 OTD 히트맵용
    var monthsSet = {};
    Object.keys(m.deliveryBySupplier).forEach(function (c) {
      m.deliveryBySupplier[c].forEach(function (d) { if (d.month) monthsSet[d.month] = true; });
    });
    var months = Object.keys(monthsSet).sort();
    var otdHeat = rows.filter(function (r) { return (m.deliveryBySupplier[r.code] || []).length; })
      .map(function (r) {
        var byMonth = {};
        (m.deliveryBySupplier[r.code] || []).forEach(function (d) { byMonth[d.month] = d.otd; });
        return { code: r.code, name: r.name, itemGroup: r.itemGroup,
          otd: months.map(function (mm) { return byMonth[mm] != null ? byMonth[mm] : null; }),
          score: r.scores['조달'], grade: r.grades['조달'] };
      }).sort(function (a, b) { return b.score - a.score; });

    var ltRows = rows.filter(function (r) { return r.deliv && r.deliv.ltNow; })
      .map(function (r) { return { code: r.code, name: r.name, itemGroup: r.itemGroup,
        ltNow: r.deliv.ltNow, ltPrev: r.deliv.ltPrev,
        incPct: Math.round(r.deliv.ltInc * 1000) / 10, delayCount: r.deliv.delayCount, reason: r.deliv.reason }; })
      .sort(function (a, b) { return b.incPct - a.incPct; });

    var stockoutRows = rows.filter(function (r) { return r.deliv && r.deliv.ltNow && r.deliv.stockoutRisk > 0.15; })
      .map(function (r) {
        var s = m.suppliers.filter(function (x) { return x.code === r.code; })[0] || {};
        return { code: r.code, name: r.name, itemGroup: r.itemGroup, item: r.item,
          stockDays: s.stockDays || 0, ltNow: r.deliv.ltNow,
          gap: Math.round((r.deliv.ltNow - (s.stockDays || 0)) * 10) / 10,
          risk: Math.round(r.deliv.stockoutRisk * 100) / 100 };
      }).sort(function (a, b) { return b.gap - a.gap; });

    var riskRows = rows.filter(function (r) { return r.grades['조달'] >= 1; })
      .sort(function (a, b) { return b.scores['조달'] - a.scores['조달']; })
      .map(function (r) { return { code: r.code, name: r.name, country: r.country, itemGroup: r.itemGroup,
        spend: r.spend, sourcing: r.sourcing, md: r.md,
        otd: r.deliv ? r.deliv.otd : null, ltInc: r.deliv ? Math.round(r.deliv.ltInc * 1000) / 10 : null,
        score: r.scores['조달'], grade: r.grades['조달'], source: r.axisSource['조달'],
        totalScore: r.totalScore, totalGrade: r.totalGrade }; });

    var otdNum = 0, otdDen = 0;
    rows.forEach(function (r) { if (r.deliv && r.deliv.otd) { otdNum += r.deliv.otd * (r.spend || 1); otdDen += (r.spend || 1); } });

    return {
      success: true, source: m.source, menu: getMenuLinks(), gradeLabel: SCRM_GRADE_LABEL,
      months: months, otdHeat: otdHeat, ltRows: ltRows, stockoutRows: stockoutRows, riskRows: riskRows,
      kpi: {
        avgOtd: otdDen ? Math.round(otdNum / otdDen * 10) / 10 : 0,
        ltUpCount: ltRows.filter(function (x) { return x.incPct >= 15; }).length,
        stockoutCount: stockoutRows.filter(function (x) { return x.risk >= 0.3; }).length,
        highCount: rows.filter(function (r) { return r.grades['조달'] >= 3; }).length
      }
    };
  }, { success: false, message: '조달 데이터 로드 실패' });
}

/* ---------------------------------------------------------------------
 * 5-4. 경영악화
 * ------------------------------------------------------------------- */
function SCRM_getFinance() {
  return SRM_safe_(function () {
    var m = SCRM_model_();
    var rows = SCRM_computeScores_();

    var withFin = rows.filter(function (r) { return r.fin && (r.fin.debtRatio || r.fin.flags && r.fin.flags.length); });

    var scorecard = withFin.map(function (r) {
      var f = r.fin;
      return { code: r.code, name: r.name, country: r.country, itemGroup: r.itemGroup, spend: r.spend,
        sourcing: r.sourcing, isSingle: r.isSingle, quarter: f.quarter, grade: f.grade,
        debtRatio: f.debtRatio, currentRatio: f.currentRatio, opMargin: f.opMargin, iscr: f.iscr,
        light: {
          debt: f.debtRatio >= 300 ? 'r' : f.debtRatio >= 200 ? 'y' : 'g',
          liq: f.currentRatio < 80 ? 'r' : f.currentRatio < 110 ? 'y' : 'g',
          opm: f.opMargin < 0 ? 'r' : f.opMargin < 3 ? 'y' : 'g',
          iscr: f.iscr > 0 && f.iscr < 1 ? 'r' : (f.iscr < 2.5 ? 'y' : 'g')
        },
        flags: f.flags, score: r.scores['경영'], gradeNum: r.grades['경영'] };
    }).sort(function (a, b) { return b.score - a.score; });

    var matrix = withFin.map(function (r) {
      var dep = r.fin.dependency || 0, sc = r.scores['경영'];
      var q = (dep >= 40 && sc >= 50) ? '공동리스크(즉시)' : (dep >= 40) ? '의존편중 관리'
            : (sc >= 50) ? '재무위험 관리' : '안정';
      return { code: r.code, name: r.name, dependency: dep, score: sc, grade: r.grades['경영'],
        spend: r.spend, isSingle: r.isSingle, quadrant: q };
    });

    var alerts = [];
    withFin.forEach(function (r) {
      (r.fin.flags || []).forEach(function (fl) {
        alerts.push({ code: r.code, name: r.name, quarter: r.fin.quarter, flag: fl,
          severe: SCRM_SEVERE_FLAG_RE.test(fl), score: r.scores['경영'] });
      });
    });
    alerts.sort(function (a, b) { return (b.severe - a.severe) || (b.score - a.score); });

    var riskRows = rows.filter(function (r) { return r.grades['경영'] >= 1; })
      .sort(function (a, b) { return b.scores['경영'] - a.scores['경영']; })
      .map(function (r) { return { code: r.code, name: r.name, country: r.country, itemGroup: r.itemGroup,
        spend: r.spend, sourcing: r.sourcing, md: r.md, isSingle: r.isSingle,
        debtRatio: r.fin ? r.fin.debtRatio : null, grade: r.grades['경영'], score: r.scores['경영'],
        source: r.axisSource['경영'], flags: r.fin ? r.fin.flags : [],
        totalScore: r.totalScore, totalGrade: r.totalGrade }; });

    var watchSpend = 0;
    rows.forEach(function (r) { if (r.grades['경영'] >= 3) watchSpend += r.spend; });

    return {
      success: true, source: m.source, menu: getMenuLinks(), gradeLabel: SCRM_GRADE_LABEL,
      scorecard: scorecard, matrix: matrix, alerts: alerts, riskRows: riskRows,
      kpi: {
        watchCount: rows.filter(function (r) { return r.grades['경영'] >= 2; }).length,
        singleWatchCount: rows.filter(function (r) { return r.grades['경영'] >= 3 && r.isSingle; }).length,
        watchSpend: Math.round(watchSpend),
        alertCount: alerts.length
      }
    };
  }, { success: false, message: '경영 데이터 로드 실패' });
}

/* ---------------------------------------------------------------------
 * 6. 내장 샘플 데이터 — DB 시트 연결 전에도 전 대시보드가 즉시 렌더되도록
 * ------------------------------------------------------------------- */
function SCRM_sampleData_() {
  var suppliers = [
    ['V001','한신정밀','KR','창원',35.228,128.681,'기구','가공 하우징',4200,'이원','중',4,45,'김민준'],
    ['V002','東光전자','JP','오사카',34.694,135.502,'전장','커넥터',3100,'단일','하',9,20,'이정은'],
    ['V003','Taiyo Semi','TW','신주',24.813,120.968,'반도체','MCU',8600,'단일','하',12,15,'박재용'],
    ['V004','Chang Materials','CN','선전',22.543,114.058,'원자재','희토류 자석',5200,'단일','하',10,10,'김유범'],
    ['V005','Neodyne Mag','CN','바오터우',40.657,109.840,'원자재','네오디뮴 소재',2800,'단일','하',14,8,'김유범'],
    ['V006','베트남ENG','VN','호치민',10.823,106.630,'기구','판금',1500,'다원','상',3,60,'정수진'],
    ['V007','Rhein Optik','DE','뮌헨',48.135,11.582,'광학','렌즈모듈',3900,'이원','중',6,30,'서주원'],
    ['V008','Galil Sensor','IL','하이파',32.794,34.989,'전장','초음파 센서',2600,'단일','하',11,18,'이은호'],
    ['V009','Suzhou Cable','CN','쑤저우',31.299,120.585,'전장','케이블 하네스',1800,'이원','중',4,35,'이정은'],
    ['V010','대한스틸','KR','포항',36.019,129.343,'원자재','냉연강판',2400,'다원','상',2,40,'김민준'],
    ['V011','Kyushu Chem','JP','후쿠오카',33.590,130.402,'원자재','특수 접착제',1200,'단일','중',7,25,'조효석'],
    ['V012','Cebu Assembly','PH','세부',10.316,123.885,'반도체','패키징',3300,'이원','중',5,22,'박재용']
  ];
  var S = suppliers.map(function (a) {
    return { '협력사코드':a[0],'협력사명':a[1],'국가':a[2],'도시':a[3],'위도':a[4],'경도':a[5],
      '품목군':a[6],'주력품목':a[7],'연간거래액(백만원)':a[8],'소싱유형':a[9],
      '대체가능성':a[10],'대체소요기간(개월)':a[11],'재고커버리지(일)':a[12],'담당MD':a[13],'비고':'' };
  });

  var events = [
    ['G01','지정학','수출통제','중국 갈륨·게르마늄·안티모니 수출 허가제','2025-08-11',3,'진행','CN','반도체,원자재,전장','V004',null,null,null,'대체 원산지(호주·캐나다) 발굴, 6개월분 안전재고 확보','진행','https://example.com/ga-ge'],
    ['G02','지정학','수출통제','중국 희토류 자석 수출 통제 강화','2025-07-02',4,'진행','CN','원자재','V004,V005',null,null,null,'자석 이원화 소싱(일본·베트남) 검토, 설계 대체(페라이트) 병행','진행','https://example.com/rare-earth'],
    ['G03','지정학','지진','대만 신주 규모 6.2 지진 — 반도체 클러스터 인근','2025-08-25',3,'진행','TW','반도체',null,24.80,120.97,120,'Taiyo Semi 라인 피해 확인 중, 대체 MCU 재고 스캔','진행','https://example.com/tw-quake'],
    ['G04','지정학','지진','일본 난카이 트로프 지진 경보 상향','2025-08-30',2,'진행','JP','전장,원자재,광학',null,33.0,136.0,300,'간사이권 협력사 BCP 점검 요청','미착수','https://example.com/jp-nankai'],
    ['G05','지정학','전쟁','이스라엘-헤즈볼라 교전 확대 — 하이파 산업지대','2025-08-18',3,'진행','IL','전장',null,32.79,34.99,60,'Galil Sensor 출하 지연 대비, 항공 운송 전환 협의','진행','https://example.com/israel'],
    ['G06','지정학','물류차질','홍해·수에즈 우회로 해상운임 급등·리드타임 +14일','2025-06-15',2,'완화','전세계','광학,전장,기구',null,20.0,38.5,null,'유럽발 물량 조기 발주, 일부 항공 전환','진행','https://example.com/red-sea'],
    ['G07','지정학','무역제재','미국 대중 반도체 장비·부품 추가 규제','2025-07-20',2,'진행','CN,US','반도체',null,null,null,null,'규제 품목 BOM 스크리닝, 비중국산 대체 라인 확인','진행','https://example.com/us-cn'],
    ['C01','원가','시황급등','니켈·네오디뮴 가격 3개월 20%+ 급등','2025-08-05',3,'진행','','원자재,전장',null,null,null,null,'분기 계약가 재협상, 대체 소재 원가영향 분석','진행',''],
    ['F01','경영','신용하락','Galil Sensor 신용등급 하향(BB→B), 이자보상배율 1 미만','2025-08-20',3,'진행','','전장','V008',null,null,null,'대체처 발굴 착수, 핵심품목 3개월분 재고 선확보','진행','']
  ];
  var E = events.map(function (a) {
    return { '이벤트ID':a[0],'카테고리':a[1],'세부유형':a[2],'제목':a[3],'발생일':a[4],'심각도':a[5],
      '진행상태':a[6],'영향지역':a[7],'영향품목군':a[8],'영향협력사코드':a[9],
      '지도위도':a[10],'지도경도':a[11],'영향반경km':a[12],'대응계획':a[13],'대응상태':a[14],'출처URL':a[15] };
  });

  var origins = [
    ['V004','희토류 자석','네오디뮴','CN',85],['V004','희토류 자석','디스프로슘','CN',92],
    ['V005','네오디뮴 소재','네오디뮴','CN',88],['V003','MCU','갈륨','CN',40],
    ['V003','MCU','게르마늄','CN',35],['V008','초음파 센서','갈륨','CN',30],
    ['V002','커넥터','안티모니','CN',25],['V010','냉연강판','철광석','AU',55],
    ['V007','렌즈모듈','형석','CN',45]
  ].map(function (a) { return { '협력사코드':a[0],'품목':a[1],'투입원자재':a[2],'원산지국가':a[3],'원산지의존도(%)':a[4] }; });

  var scenarios = [
    ['S1','대만해협 위기','G03','TW,CN','반도체,전장','대만 봉쇄 + 중국 동시 리스크 시 반도체·전장 전면 노출'],
    ['S2','희토류 전면 통제','G01,G02','CN','원자재,반도체,전장','중국이 갈륨·게르마늄·희토류 수출을 전면 중단하는 상황'],
    ['S3','동아시아 대지진','G03,G04','JP,TW','반도체,전장,원자재,광학','일본·대만 동시 대형 지진 — 동아시아 소싱 마비']
  ].map(function (a) { return { '시나리오ID':a[0],'시나리오명':a[1],'포함이벤트ID':a[2],'영향지역':a[3],'영향품목군':a[4],'설명':a[5] }; });

  var indices = [
    ['니켈','원자재',18500,15700,17.8,'전장'],
    ['네오디뮴','원자재',92,75,22.7,'원자재,전장'],
    ['구리','원자재',9600,8950,7.3,'전장,케이블'],
    ['알루미늄','원자재',2450,2380,2.9,'기구'],
    ['냉연강판','원자재',720,750,-4.0,'기구,원자재'],
    ['형석','원자재',480,455,5.5,'광학'],
    ['USD/KRW','환율',1385,1318,5.1,''],
    ['SCFI 종합운임','운임',2180,1615,35.0,''],
    ['두바이유','운임',82,75,9.3,'']
  ].map(function (a) { return { '지수명':a[0],'구분':a[1],'최신값':a[2],'3개월전값':a[3],'3개월변동률(%)':a[4],'연결품목군':a[5],'비고':'' }; });

  var costReqs = [
    ['V010','2025-08-22',12,'원자재가 인상','검토'],        // 냉연강판 -4% 인데 12% 요청 → 역행
    ['V004','2025-08-10',9,'희토류 통제·환율','검토'],
    ['V009','2025-08-18',7,'구리·환율 상승','수용'],
    ['V001','2025-08-25',10,'인건비·환율','검토']            // 연결지수 약세인데 두 자릿수 요청
  ].map(function (a) { return { '협력사코드':a[0],'요청일':a[1],'요청률(%)':a[2],'사유':a[3],'상태':a[4] }; });

  var delivery = [
    ['V003','2025-08',78,78,60,12,4,'지진 여파·자재 수급'],
    ['V003','2025-07',85,66,60,7,2,'자재 수급'],
    ['V012','2025-08',88,26,24,5,2,'테스트 설비 병목'],
    ['V009','2025-08',84,41,30,6,3,'전선 원자재 지연'],
    ['V006','2025-08',95,20,20,1,0,''],
    ['V001','2025-08',96,45,44,1,1,''],
    ['V008','2025-08',82,34,22,4,3,'출하 지연(물류)']
  ].map(function (a) { return { '협력사코드':a[0],'기준월':a[1],'OTD(%)':a[2],'평균리드타임_현재(일)':a[3],
    '평균리드타임_3개월전(일)':a[4],'미입고건수':a[5],'지연횟수_최근3개월':a[6],'주요지연사유':a[7] }; });

  var finance = [
    ['V008','2025-2Q',320,65,-2.0,0.8,'B',22,'신용등급하락,세금체납',''],
    ['V011','2025-2Q',285,92,1.5,1.4,'BB',18,'',''],
    ['V005','2025-2Q',215,105,4.2,2.1,'BBB',12,'',''],
    ['V009','2025-2Q',240,88,2.8,1.6,'BB',35,'세금체납',''],
    ['V002','2025-2Q',175,118,6.0,3.2,'A-',9,'',''],
    ['V004','2025-2Q',260,95,5.5,2.4,'BBB',15,'',''],
    ['V006','2025-2Q',150,140,7.1,4.0,'A',6,'','']
  ].map(function (a) { return { '협력사코드':a[0],'기준분기':a[1],'부채비율(%)':a[2],'유동비율(%)':a[3],
    '영업이익률(%)':a[4],'이자보상배율':a[5],'신용등급':a[6],'당사매출의존도(%)':a[7],'조기경보플래그':a[8],'비고':a[9] }; });

  return { suppliers: S, events: E, origins: origins, scenarios: scenarios,
    indices: indices, costReqs: costReqs, delivery: delivery, finance: finance };
}
