/* =====================================================================
 * RiskMap_Code.gs  ·  메-SCRM 지정학 리스크 대시보드 (SCM Map) 백엔드
 * ---------------------------------------------------------------------
 * 공용 로직            →  통합_common.gs
 * 데이터/스코어링      →  SCRM_score.gs  (SCRM_getRiskMap)
 *
 * 이 파일은 doGet + 포털 복귀 링크만 담는다.
 * ===================================================================== */

/** 포털 웹앱 URL — 배포 후 실제 exec URL 로 교체 (헤더 "포털로" 링크용) */
var SCRM_PORTAL_URL = '__PORTAL_WEBAPP_URL__';

function doGet(e) {
  var t = HtmlService.createTemplateFromFile('index');
  t.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  t.portalUrl = SCRM_PORTAL_URL;
  return t.evaluate()
    .setTitle('메-SCRM · 지정학 리스크 맵')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** 시나리오/필터 파라미터를 받아 재계산 (프론트에서 호출) */
function RiskMap_query(params) {
  return SCRM_getRiskMap(params || {});
}

function RiskMap_reload(params) {
  SCRM_clearCache();
  return SCRM_getRiskMap(params || {});
}
