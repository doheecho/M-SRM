# 메-SCRM 로컬 미리보기 빌더 (실제 로직은 build.py). PowerShell 실행 편의용 래퍼.
$py = Join-Path $PSScriptRoot 'build.py'
$exe = Get-Command py -ErrorAction SilentlyContinue
if (-not $exe) { $exe = Get-Command python -ErrorAction SilentlyContinue }
if (-not $exe) { Write-Error 'Python 이 필요합니다 (py 또는 python 명령).'; exit 1 }
& $exe.Source $py
