#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
메-SCRM 로컬 미리보기 빌더 — GAS 없이 브라우저에서 바로 확인.

Portal_index.html / RiskMap_index.html 를 읽어서:
  - <?!= include('통합_theme'); ?>  → 통합_theme.html 삽입
  - <?!= include('통합_header'); ?> → 통합_header.html + google.script.run 목업 삽입
  - <?= srmTheme ?> 등 GAS 템플릿 태그 치환
  - google.script.run → 브라우저 목업 (SCRM_score.gs 의 내장 샘플 데이터로 응답)
→ _local/Portal.html , _local/RiskMap.html 생성.

실행:  python _local/build.py       (또는  py _local\build.py)
결과:  _local/Portal.html 더블클릭 → 크롬에서 열림 (CDN 때문에 인터넷 필요)
"""
import pathlib
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

LOCAL = pathlib.Path(__file__).resolve().parent
ROOT = LOCAL.parent


def read(name: str) -> str:
    return (ROOT / name).read_text(encoding="utf-8")


THEME = read("통합_theme.html")
HEADER = read("통합_header.html")
ENGINE = read("SCRM_score.gs")

SHIM = """
<script>
/* ===== 로컬 미리보기 목업 — GAS 런타임 대체 ===== */
var Logger = { log: function(){ try{ console.log.apply(console, arguments); }catch(e){} } };
function SRM_safe_(fn, fb){ try { return fn(); } catch(e){ return fb; } }
function SRM_readSheet_(){ throw new Error('local-preview: 스프레드시트 없음 → 샘플 데이터 사용'); }
function SRM_toObjects_(){ return []; }
function SRM_indexBy_(){ return {}; }
function SRM_clearSheetCache_(){}
function SRM_getUserContext_(){
  return { email:'test@ai.samsunghealthcare.com', id:'test', name:'홍길동', dept:'구매그룹', hasFullAccess:true };
}
function getMenuLinks(){
  return [[{title:'공급망 리스크 포털',url:'Portal.html'},{title:'지정학 리스크 맵',url:'RiskMap.html'}]];
}
function fetchUserDeptAndName(){ return '구매그룹 홍길동'; }
function getUserDetails(){ return { email:'test@ai.samsunghealthcare.com', id:'test', name:'홍길동', dept:'구매그룹' }; }
</script>
<script>
__ENGINE__
</script>
<script>
__CODE__
</script>
<script>
/* google.script.run 목업 : .withSuccessHandler(cb).withFailureHandler(cb).Fn(args) → window.Fn(args) */
(function(){
  window.google = window.google || {};
  google.script = google.script || {};
  function runner(ok, fail){
    return new Proxy({}, { get:function(_, name){
      if (name === 'withSuccessHandler') return function(cb){ return runner(cb, fail); };
      if (name === 'withFailureHandler') return function(cb){ return runner(ok, cb); };
      return function(){
        var args = Array.prototype.slice.call(arguments);
        setTimeout(function(){
          try {
            var fn = window[name];
            if (typeof fn !== 'function') throw new Error('목업: 함수 없음 — ' + name);
            var res = fn.apply(null, args);
            if (ok) ok(res);
          } catch(e){ console.error('[mock]', e); if (fail) fail(e); }
        }, 30);
      };
    }});
  }
  google.script.run = runner(null, null);
  google.script.host = { close:function(){}, setHeight:function(){}, editor:{focus:function(){}} };
})();
</script>
"""


def build(src_name: str, dst_name: str, extra_js: str):
    html = read(src_name)
    header_block = HEADER + "\n" + (
        SHIM.replace("__ENGINE__", ENGINE).replace("__CODE__", extra_js)
    )
    html = html.replace("<?!= include('통합_theme'); ?>", THEME)
    html = html.replace("<?!= include('통합_header'); ?>", header_block)
    html = html.replace("<?= srmTheme ?>", "")
    html = html.replace(
        '<?!= dashboardUrls ?>',
        '{"riskmap":"RiskMap.html","cost":"Cost.html","delivery":"Delivery.html","finance":"Finance.html"}',
    )
    html = html.replace("<?= portalUrl ?>", "Portal.html")
    dst = LOCAL / dst_name
    dst.write_text(html, encoding="utf-8")
    print(f"  생성: _local/{dst_name}  ({dst.stat().st_size:,} bytes)")


if __name__ == "__main__":
    print("메-SCRM 로컬 미리보기 빌드...")
    build("Portal_index.html",   "Portal.html",   read("Portal_Code.gs"))
    build("RiskMap_index.html",  "RiskMap.html",  read("RiskMap_Code.gs"))
    build("Cost_index.html",     "Cost.html",     read("Cost_Code.gs"))
    build("Delivery_index.html", "Delivery.html", read("Delivery_Code.gs"))
    build("Finance_index.html",  "Finance.html",  read("Finance_Code.gs"))
    print("완료. _local/Portal.html 을 더블클릭하세요 (CDN 사용 — 인터넷 연결 필요).")
