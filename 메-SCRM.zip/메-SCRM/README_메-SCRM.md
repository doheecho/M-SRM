# 메-SCRM · 공급망 리스크 관리 대시보드

메-SRM 과 **동일한 통합 테마(common / header / theme)** 를 그대로 상속하는 별도 GAS 웹앱 묶음.
협력사를 4대 리스크 축(지정학·원가·조달·경영)으로 통합 모니터링한다.

| 축 | 대시보드 | 상태 |
|---|---|---|
| 통합 | **Portal** — 전사 리스크 인덱스 · 4축 히트맵 · Top 위험 협력사 · 이벤트 피드 · 레이더 모달 | ✅ |
| 지정학 | **RiskMap** (SCM Map) — 수출통제·지진·전쟁·물류차질을 지도에 얹어 영향 협력사 식별 + 시나리오 what-if | ✅ |
| 원가 | **Cost** — 원자재·환율·운임 지수, 품목군 민감도, 협력사 인상요청 시황역행 탐지 | ✅ |
| 조달 | **Delivery** — 협력사×월 OTD 히트맵, 리드타임 증가, 결품 위험 | ✅ |
| 경영 | **Finance** — 재무건전성 신호등, 조기경보 플래그, 의존도×재무위험 2×2 매트릭스 | ✅ |

- 점수 계산은 **전 모듈이 `SCRM_score.gs` 한 파일**을 공유한다.
- 상세 문서: [`docs/스코어링_상세.md`](docs/스코어링_상세.md) · [`docs/모듈_설계.md`](docs/모듈_설계.md) · [`docs/평가방법론_참고.md`](docs/평가방법론_참고.md) · [`_스프레드시트_스키마.md`](_스프레드시트_스키마.md)

---

## 파일 구성

```
통합_common.gs / 통합_theme.html / 통합_header.html   메-SRM 원본 복사 — 수정 금지, 원본과 동기화

SCRM_score.gs        ★ 공용 데이터 접근 + 스코어링 엔진 (모든 모듈 프로젝트에 복사)
                       · SCRM_DB_SS_ID                ← 데이터 스프레드시트 ID 입력
                       · SCRM_getPortal / SCRM_getSupplier(code)
                       · SCRM_getRiskMap(params)       (+시나리오)
                       · SCRM_getCost / SCRM_getDelivery / SCRM_getFinance
                       · SCRM_computeScores_()         4축 점수 단일 계산
                       · 내장 샘플 데이터 폴백(8개 시트분)

Portal_*    (Code.gs / index.html / appsscript.json)   통합 포털
RiskMap_*                                              지정학 리스크 맵 (Leaflet)
Cost_*                                                 원가 / 시황
Delivery_*                                             조달 / 납기
Finance_*                                              경영악화

docs/스코어링_상세.md    E·V·T 계식 전부 + 워크드 예시 + 튜닝 포인트 (우리 코드가 뭘 하나)
docs/모듈_설계.md        모듈별 API·화면 영역·데이터 소스
docs/평가방법론_참고.md   업계 점수법 4대 계열·왜 이걸 골랐나·지정학 심각도 rubric·캘리브레이션
_스프레드시트_스키마.md   수기 업로드 시트 8개 열 정의
_local/                 GAS 없이 브라우저에서 보는 미리보기 빌더
```

---

## 로컬에서 바로 보기 (GAS 배포 없이)

1. `py _local\build.py` 실행 (또는 `powershell -ExecutionPolicy Bypass -File .\_local\build.ps1`).
   → `_local\` 에 `Portal.html` `RiskMap.html` `Cost.html` `Delivery.html` `Finance.html` 생성.
2. **`_local\Portal.html` 더블클릭** → 크롬. 대시보드 카드로 나머지 4개 이동.
3. 인터넷 필요(Bootstrap / Chart.js / Leaflet / OSM 타일 CDN). DB 시트 없이 **내장 샘플**로 렌더.

빌더가 하는 일: `통합_theme`/`통합_header` include 인라인 + `google.script.run` 을 브라우저 목업으로
대체(SpreadsheetApp 없이 `SCRM_score.gs` 샘플 폴백). `*_index.html` / `SCRM_score.gs` 수정 후 빌더만 재실행.
※ `_local\*.html` 은 자동 생성물 — 직접 편집 금지, 원본은 루트의 `*_index.html`.

---

## 배포 절차 (clasp 또는 수동)

각 모듈은 **독립 GAS 프로젝트**. 프로젝트마다 공용 4파일
(`통합_common.gs`, `통합_theme.html`, `통합_header.html`, `SCRM_score.gs`)
+ 그 모듈의 `*_Code.gs` / `index.html`(파일명 `index`) / `appsscript.json` 을 넣는다.

1. **데이터 시트 준비**
   - 구글시트 "메-SCRM DB" 생성 → `_스프레드시트_스키마.md` 대로 탭 생성
     (필수: `협력사마스터`·`리스크이벤트` / 선택: 나머지 6개).
   - 시트 URL 의 `/d/<ID>/` 값을 `SCRM_score.gs` → `SCRM_DB_SS_ID` 에 붙여넣기.
   - 메뉴/사용자정보는 메-SRM 과 동일하게 `통합_common.gs` 의 `SRM_ADMIN_SS_ID` 사용 — 그대로 둠.

2. **5개 프로젝트 배포** (Portal / RiskMap / Cost / Delivery / Finance)
   - 각각 웹앱 배포(도메인 내부, 배포자 권한 실행) → exec URL 확보.

3. **URL 상호 연결**
   - `Portal_Code.gs` → `SCRM_DASHBOARD_URLS` 의 `riskmap`/`cost`/`delivery`/`finance` 에 각 exec URL.
     (값이 `__` 로 시작하면 포털 카드가 "준비중" 비활성으로 뜬다.)
   - `RiskMap_Code.gs` / `Cost_Code.gs` / `Delivery_Code.gs` / `Finance_Code.gs` → `SCRM_PORTAL_URL` 에 Portal exec URL.
   - Portal 재배포.

4. **메뉴 등록**
   - 메-SRM 의 `바로가기` 시트에 "공급망 리스크 포털" 행 추가 → 전 모듈 헤더 드롭다운에 노출.

---

## 동작 확인 체크리스트

- [ ] `SCRM_DB_SS_ID` 미입력에서도 5개 화면이 **샘플 데이터**로 렌더된다.
- [ ] 헤더 ☰ → 테마설정: Dark → 배경·표·차트·지도가 앰버/차콜로 전환, 무한루프/콘솔에러 없음.
- [ ] Portal: 히트맵/Top10 협력사 클릭 → 4축 레이더 모달. 4축 컬럼 모두 값이 찬다.
- [ ] RiskMap: 이벤트 ▲ 클릭 → 우패널 영향 협력사 목록 + 지도 빨간 점선. 시나리오 선택 → 재계산.
- [ ] Cost: "인상요청 vs 시황" 에서 원자재 지수 대비 과한 요청에 **역행** 배지.
- [ ] Delivery: 협력사×월 OTD 히트맵 색상, 결품 위험 갭 계산.
- [ ] Finance: 재무 신호등, 조기경보 플래그(중대=빨강칩), 2×2 버블 매트릭스.
- [ ] `리스크이벤트` 에 `원가`/`조달`/`경영` 행 추가 → Portal·해당 대시보드에 즉시 반영.

---

## 다음 단계 후보

- 각 대시보드에 **대응계획 트래킹**(협력사별 컨틴전시 플랜 상태) 컬럼/뷰.
- Cost: 계약 갱신 임박 ∩ 시황 불리 알림, 환헤지 커버리지 입력.
- Delivery: 발주→확정→출하→입고 단계별 지연 Sankey, 지연사유 파레토.
- Finance: 분기 추세 스파크라인, Altman Z-score 게이지.
- 이벤트/지표를 합성해 **통합 이벤트 피드**에 원가·조달·경영 신호도 노출(현재 피드는 `리스크이벤트` 행만).
