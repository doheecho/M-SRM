/* =====================================================================
 * Partner_Code.gs  ·  구매 협력업체 관리대장 모듈 백엔드
 * ---------------------------------------------------------------------
 * 공용 로직(include / getActiveUserEmail / fetchUserDeptAndName /
 * checkUserFullAccess / logAccess / getMenuLinks)은 통합_common.gs 로 이관.
 * 이 파일은 협력사 그리드/대시보드 고유 로직만 담는다.
 *
 * 최적화(개발계획서 §4-1):
 *  - 시트 접근을 SRM_readSheet_() 단일 배치 읽기 + CacheService 로 최소화
 *  - 사용자 컨텍스트(이메일·권한)를 1회 조회로 통합
 * ===================================================================== */

const SHEET_NAME = '협력업체 관리대장';
const HEADER_ROW = 4;
const DATA_START_ROW = 5;

const COLUMN_MAPPING = [
  3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 22, 98, 26, 27, 28, 29, 30, // 25 columns (W열의 23(Map)을 제거하고 CT열의 98(주거래사업부)을 해당 위치로 앞당김!)
  31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, // 18 columns (2013년~2030년 당사구매액)
  58, 59, 60, 61, 62, 63, 64, 65, 66, 67, // 10 columns (매출액 21년~30년)
  68, 69, 70, 71, 72, 73, 74, 75, 76, 77, // 10 columns (영업이익 21년~30년)
  78, 79, 80, 81, 82, 83, 84, 85, 86, 87, // 10 columns (당기순이익 21년~30년)
  88, 89, 90, 91, 92, 93, 94, 95, 96, 97, // 10 columns (이익잉여금 21년~30년)
  99, 102, 105, 108, // 4 columns (주소 공장1, 주소 공장2, 주소 공장3, 주소 공장4 - 한칸씩 왼쪽 자동 시프트)
  111, 112, 113, 114, 115, 116, 117 // 7 columns (Etc1~Etc7 - 한칸씩 왼쪽 자동 시프트)
];

const STATUS_COL = 3;
const PLANT_COL = 8;
const TYPE_COL = 9;
const BIZ_TYPE_COL = 11;
const SUBCONTRACT_COL = 15;
const LISTING_STATUS_COL = 17;
const REVENUE_COL = 57;
const LATITUDE_COL = 24;
const LONGITUDE_COL = 25;

const SECURITY_CONFIG = {
  maskedColumnNumbers: [
    20, 21, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57
  ]
};

function doGet(e) {
  const template = HtmlService.createTemplateFromFile('index');
  template.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  const params = {
    status: (e && e.parameter && e.parameter.status) || '정규',
    plant: (e && e.parameter && e.parameter.plant) || '전체',
    type: (e && e.parameter && e.parameter.type) || '전체',
    bizType: (e && e.parameter && e.parameter.bizType) || '전체',
    subcontract: (e && e.parameter && e.parameter.subcontract) || '전체',
    listingStatus: (e && e.parameter && e.parameter.listingStatus) || '전체',
    revenue: (e && e.parameter && e.parameter.revenue) || '전체',
    partnerType: (e && e.parameter && e.parameter.partnerType) || '당사 거래선'
  };

  // 개발계획서 §4-2: doGet 은 빈 껍데기를 즉시 반환. 데이터는 클라이언트가
  // google.script.run.getData(params) 로 비동기 적재 → 첫 화면 5~15초 흰화면 제거
  template.initialDataString = 'null';
  template.initialParamsString = JSON.stringify(params);

  return template.evaluate()
    .setTitle('구매 협력업체 관리대장')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getData(params) {
  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    if (!spreadsheet) return { success: false, message: '활성 스프레드시트를 찾을 수 없습니다.' };
    const ssId = spreadsheet.getId();

    // 당사 거래선 → '협력업체 관리대장', IPC 거래선 → 'IPC Vendor'
    const selectedSheetName = (params && params.partnerType === 'IPC 거래선') ? 'IPC Vendor' : SHEET_NAME;

    // 사용자 컨텍스트 1회 조회 (이메일 + 보안조회 권한)
    const userCtx = SRM_getUserContext_();
    const hasFullAccess = userCtx.hasFullAccess;

    // 대상 시트 단일 배치 읽기 (+ 청크 캐시). COLUMN_MAPPING 은 117열까지만 쓰므로
    // 그 뒤 버퍼열은 읽지 않는다(§4-1 D).
    let allSheetData;
    try {
      allSheetData = SRM_readSheet_(selectedSheetName, { id: ssId, ttl: 1800, cols: 117 });
    } catch (readErr) {
      return { success: false, message: `'${selectedSheetName}' 시트를 찾을 수 없습니다.` };
    }

    if (!allSheetData || allSheetData.length < DATA_START_ROW) {
      const headersArray = (allSheetData && allSheetData[HEADER_ROW - 1]) ? allSheetData[HEADER_ROW - 1] : [];
      return { success: true, headers: getHeaders(headersArray), data: [], currentFilters: params, filterOptions: {}, dashboardMeta: [] };
    }

    const headersArray = allSheetData[HEADER_ROW - 1];
    const headers = getHeaders(headersArray);
    const fullRawRows = allSheetData.slice(DATA_START_ROW - 1);

    const plantOptions = new Set(), typeOptions = new Set(), bizTypeOptions = new Set(),
      revenueOptions = new Set(), listingStatusOptions = new Set();

    const maskedSet = {};
    SECURITY_CONFIG.maskedColumnNumbers.forEach(function (n) { maskedSet[n] = true; });

    const allData = fullRawRows.map(row => {
      const statusVal = String(row[STATUS_COL - 1] || '').trim();
      const plantVal = String(row[PLANT_COL - 1] || '').trim();
      const typeVal = String(row[TYPE_COL - 1] || '').trim();
      const bizTypeVal = String(row[BIZ_TYPE_COL - 1] || '').trim();
      const subcontractVal = String(row[SUBCONTRACT_COL - 1] || '').trim();
      const listingStatusVal = String(row[LISTING_STATUS_COL - 1] || '').trim();
      const revenueVal = String(row[REVENUE_COL - 1] || '').trim();

      if (plantVal) plantOptions.add(plantVal);
      if (typeVal) typeOptions.add(typeVal);
      if (bizTypeVal) bizTypeOptions.add(bizTypeVal);
      if (listingStatusVal) listingStatusOptions.add(listingStatusVal);
      if (revenueVal) revenueOptions.add(revenueVal);

      const rowValues = COLUMN_MAPPING.map(colIndex => {
        let val = row[colIndex - 1] || '';
        if (!hasFullAccess && maskedSet[colIndex]) val = 'MASKED_SECURE_DATA';
        return val;
      });

      return {
        values: rowValues,
        lat: row[LATITUDE_COL - 1] || '',
        lon: row[LONGITUDE_COL - 1] || '',
        factory1Lat: row[100 - 1] || '',
        factory1Lon: row[101 - 1] || '',
        factory2Lat: row[103 - 1] || '',
        factory2Lon: row[104 - 1] || '',
        factory3Lat: row[106 - 1] || '',
        factory3Lon: row[107 - 1] || '',
        factory4Lat: row[109 - 1] || '',
        factory4Lon: row[110 - 1] || '',
        filters: {
          status: statusVal,
          plant: plantVal,
          type: typeVal,
          bizType: bizTypeVal,
          subcontract: subcontractVal,
          listingStatus: listingStatusVal,
          revenue: revenueVal
        }
      };
    });

    const revenueSortOrder = ['100억 미만', '100~500억', '500~1,000억', '1,000억 이상', '미확인'];
    const sortedRevenues = Array.from(revenueOptions).sort((a, b) => {
      const ia = revenueSortOrder.indexOf(a), ib = revenueSortOrder.indexOf(b);
      if (ia === -1) return 1;
      if (ib === -1) return -1;
      return ia - ib;
    });

    const listingStatusSortOrder = ['코스피', '코스닥', '코넥스', '비상장', '개인사업자', '외자'];
    const sortedListingStatuses = Array.from(listingStatusOptions).sort((a, b) => {
      const ia = listingStatusSortOrder.indexOf(a), ib = listingStatusSortOrder.indexOf(b);
      if (ia === -1) return 1;
      if (ib === -1) return -1;
      return ia - ib;
    });

    const dashboardMeta = getDashboardMeta(ssId);

    return {
      success: true,
      headers: headers,
      allData: allData,
      currentFilters: params,
      filterOptions: {
        plants: ['전체', ...Array.from(plantOptions).sort()],
        types: ['전체', ...Array.from(typeOptions).sort()],
        bizTypes: ['전체', ...Array.from(bizTypeOptions).sort()],
        subcontracts: ['전체', '대기업', '중견', '중소', '비대상'],
        listingStatuses: ['전체', ...sortedListingStatuses],
        revenues: ['전체', ...sortedRevenues]
      },
      dashboardMeta: dashboardMeta,
      userEmail: userCtx.email,
      userName: userCtx.name,
      userDept: userCtx.dept,
      hasFullAccess: hasFullAccess,
      menuGroups: getMenuLinks()   // 헤더용 — 별도 왕복 없이 함께 전달(§4-2 B)
    };
  } catch (e) {
    return { success: false, message: `데이터 로딩 중 오류 발생: ${e.message}` };
  }
}

function getDashboardMeta(ssId) {
  return SRM_safe_(function () {
    const dbData = SRM_readSheet_('대시보드', { id: ssId || SpreadsheetApp.getActiveSpreadsheet().getId(), ttl: 1800 });
    if (!dbData || !dbData.length) return [];

    function extractRange(rangeStr) {
      const match = rangeStr.match(/([A-Z]+)([0-9]+):([A-Z]+)([0-9]+)/);
      if (!match) return [];
      let cStart = 0; for (let i = 0; i < match[1].length; i++) cStart = cStart * 26 + match[1].charCodeAt(i) - 64; cStart--;
      const rStart = parseInt(match[2], 10) - 1;
      let cEnd = 0; for (let i = 0; i < match[3].length; i++) cEnd = cEnd * 26 + match[3].charCodeAt(i) - 64; cEnd--;
      const rEnd = parseInt(match[4], 10) - 1;
      const res = [];
      for (let r = rStart; r <= rEnd; r++) {
        if (dbData[r]) res.push(dbData[r].slice(cStart, cEnd + 1));
      }
      return res;
    }

    const chartConfigs = {
      'status':        { range: 'B4:C6',   isSubcontract: false },
      'plant':         { range: 'E4:F7',   isSubcontract: false },
      'type':          { range: 'H4:I6',   isSubcontract: false },
      'bizType':       { range: 'K4:L10',  isSubcontract: false },
      'subcontract':   { range: 'N4:O10',  isSubcontract: true },
      'listingStatus': { range: 'Q4:R10',  isSubcontract: false }
    };

    return Object.keys(chartConfigs).map(key => {
      const config = chartConfigs[key];
      const values = extractRange(config.range);
      if (!values || values.length === 0) return null;
      const title = values[0][0];
      const labels = [];
      for (let i = 1; i < values.length; i++) {
        if (values[i][0]) labels.push(values[i][0].trim());
      }
      return { key, title, labels, isSubcontract: config.isSubcontract };
    }).filter(Boolean);
  }, []);
}

function getHeaders(fullHeadersArray) {
  return SRM_safe_(function () {
    const mainHeaders = COLUMN_MAPPING.map(colIndex => ({ name: fullHeadersArray[colIndex - 1] || '', originalColumn: colIndex }));
    const summaryHeaders = new Array(mainHeaders.length).fill(null);

    const summaryTitles = { C: '거래정보', F: '기본정보', Z: '계약정보', AE: '당사 구매액 (백만원)', BF: '매출액 (백만원)', BP: '영업이익 (백만원)', BZ: '당기순이익 (백만원)', CJ: '이익잉여금 (백만원)', Etc1: 'Etc.' };
    const SUMMARY_HEADER_COLS = { C: 3, F: 6, Z: 26, AE: 31, BF: 58, BP: 68, BZ: 78, CJ: 88, Etc1: 111 };

    const summaryKeys = Object.keys(SUMMARY_HEADER_COLS);
    for (let i = 0; i < summaryKeys.length; i++) {
      const currentKey = summaryKeys[i];
      const currentCol = SUMMARY_HEADER_COLS[currentKey];
      const currentIndex = mainHeaders.findIndex(h => h.originalColumn === currentCol);
      if (currentIndex === -1) continue;

      const nextKey = (i + 1 < summaryKeys.length) ? summaryKeys[i + 1] : null;
      const nextCol = nextKey ? SUMMARY_HEADER_COLS[nextKey] : -1;
      let nextIndex = nextCol !== -1 ? mainHeaders.findIndex(h => h.originalColumn === nextCol) : -1;
      if (nextIndex === -1) nextIndex = mainHeaders.length;

      const span = nextIndex - currentIndex;
      if (span > 0) summaryHeaders[currentIndex] = { title: summaryTitles[currentKey], span: span };
    }
    return { summary: summaryHeaders, main: mainHeaders };
  }, { summary: [], main: [] });
}
