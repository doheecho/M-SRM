/* =====================================================================
 * SCMMap_Code.gs  ·  SCM Map 모듈 백엔드
 * ---------------------------------------------------------------------
 * 공용 로직(include / logAccess / fetchUserDeptAndName /
 * checkUserFullAccess / getMenuLinks)은 통합_common.gs 로 이관.
 * 최적화(개발계획서 §4-1):
 *  - SCM Raw / 원자재SCM / 협력사 코드열 읽기를 SRM_readSheet_ 캐시로 전환
 *  - doGet 에서 동기 logAccess 제거(프론트가 비동기 호출)
 * ===================================================================== */

const SHEET_NAME = 'SCM Raw';
const HEADER_ROW = 1;
const DATA_START_ROW = 2;
const PARTNER_DB_ID = '1rQHrhLa3xNZ2DyfK1OS4jeF17xkfXobkV7joMoq4A4w';

const COLUMN_MAPPING = {
    "No": 0, "Vendor Code": 1, "Vendor Desc": 2, "Maker": 3, "개발구매": 4, "조달구매": 5,
    "협력사": 6, "국가": 7, "도시": 8, "lat": 9, "lon": 10, "품목": 11, "품목군": 12,
    "생산유형": 13, "Risk": 14, "추가1": 15, "추가2": 16, "추가3": 17, "추가4": 18, "추가5": 19
};

const COUNTRY_CODE_MAP = {
  "US": "미국", "CN": "중국", "JP": "일본", "KR": "대한민국", "VN": "베트남", "MY": "말레이시아",
  "TW": "대만", "DE": "독일", "PH": "필리핀", "IN": "인도", "ID": "인도네시아", "TH": "태국",
  "SG": "싱가포르", "MX": "멕시코", "GB": "영국", "FR": "프랑스", "IT": "이탈리아", "CA": "캐나다", "BR": "브라질"
};

const TREEVIEW_COLUMNS = ["국가", "도시", "협력사", "품목", "품목군", "생산유형"];

function doGet(e) {
  const template = HtmlService.createTemplateFromFile('index');
  template.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  // §4-2 A: doGet 은 빈 껍데기 즉시 반환, 데이터는 클라이언트가 getScmData() 로 비동기 적재
  template.initialPageDataString = 'null';
  return template.evaluate()
    .setTitle('SCM Map')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getScmData() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const ssId = ss.getId();

    let allDataValues;
    try {
      // §4-1 C: getValues (raw) — SCM Raw 는 코드/명칭/좌표뿐이라 표시서식 불필요, getDisplayValues 대비 수 배 빠름
      const raw = SRM_readSheet_(SHEET_NAME, { id: ssId, ttl: 3600, useDisplay: false });
      allDataValues = raw.slice(DATA_START_ROW - 1).map(r => r.map(v => (v == null ? '' : (typeof v === 'string' ? v : String(v)))));
    } catch (readErr) {
      throw new Error(`시트 '${SHEET_NAME}'를 찾을 수 없습니다.`);
    }

    const ctx = SRM_getUserContext_();
    const userEmail = ctx.email;

    if (!allDataValues.length) {
      return { success: true, filters: {}, allData: [], riskThemes: [], columnMapping: COLUMN_MAPPING,
        treeviewColumns: TREEVIEW_COLUMNS, userEmail: userEmail, userName: ctx.name, userDept: ctx.dept,
        menuGroups: getMenuLinks(), countryCodeMap: COUNTRY_CODE_MAP,
        vendorCodeTypes: { regular: [], ipc: [] } };
    }

    // 생산유형(N, index 13) = S~AA(18~26) 역할값 콤마 결합
    allDataValues.forEach(row => {
      const roles = [];
      for (let i = 18; i <= 26; i++) {
        const val = row[i] ? String(row[i]).trim() : "";
        if (val) roles.push(val);
      }
      row[13] = roles.join(', ');
    });

    const filters = {};
    const filterableColumns = ["국가", "도시", "품목", "품목군", "생산유형", "협력사"];

    filterableColumns.forEach(colName => {
      const colIdx = COLUMN_MAPPING[colName];
      if (colIdx === undefined) return;
      let uniqueValues;
      if (colName === "생산유형") {
        const valuesSet = new Set();
        allDataValues.forEach(row => {
          const val = row[colIdx];
          if (val) {
            String(val).split(',').forEach(v => {
              let trimmed = v.trim();
              if (trimmed.startsWith("Office")) trimmed = "Office";
              if (trimmed) valuesSet.add(trimmed);
            });
          }
        });
        uniqueValues = [...valuesSet];
        const priority = ["FAB", "Package", "Test", "원재료", "생산", "가공", "Office"];
        uniqueValues.sort((a, b) => {
          const ia = priority.indexOf(a), ib = priority.indexOf(b);
          if (ia !== -1 && ib !== -1) return ia - ib;
          if (ia !== -1) return -1;
          if (ib !== -1) return 1;
          return a.localeCompare(b);
        });
      } else {
        uniqueValues = [...new Set(allDataValues.map(row => row[colIdx]))].filter(Boolean).sort();
        if (colName === "국가") {
          const priority = ["KR", "TW", "CN", "US"];
          uniqueValues.sort((a, b) => {
            const ia = priority.indexOf(a), ib = priority.indexOf(b);
            if (ia !== -1 && ib !== -1) return ia - ib;
            if (ia !== -1) return -1;
            if (ib !== -1) return 1;
            return a.localeCompare(b);
          });
        }
      }
      filters[colName] = uniqueValues;
    });

    const riskColIdx = COLUMN_MAPPING['Risk'];
    const riskThemes = new Set();
    if (riskColIdx !== undefined) {
      allDataValues.forEach(row => {
        if (row[riskColIdx]) {
          String(row[riskColIdx]).split('#').map(t => t.trim()).filter(Boolean).forEach(theme => riskThemes.add(theme));
        }
      });
    }

    return {
      success: true,
      filters: filters,
      allData: allDataValues,
      riskThemes: [...riskThemes].sort(),
      columnMapping: COLUMN_MAPPING,
      treeviewColumns: TREEVIEW_COLUMNS,
      userEmail: userEmail,
      userName: ctx.name,
      userDept: ctx.dept,
      menuGroups: getMenuLinks(),
      countryCodeMap: COUNTRY_CODE_MAP,
      vendorCodeTypes: getVendorCodeTypes()
    };
  } catch (e) {
    Logger.log(e.toString());
    return { success: false, message: e.toString() };
  }
}

function getVendorCodeTypes() {
  return SRM_safe_(function () {
    const types = { regular: [], ipc: [] };
    const pick = (sheetName, bucket) => {
      const rows = SRM_safe_(function () {
        return SRM_readSheet_(sheetName, { id: PARTNER_DB_ID, ttl: 21600 });
      }, []);
      for (let i = 4; i < rows.length; i++) {          // 5행부터 데이터
        const val = String((rows[i] && rows[i][5]) || '').trim();  // F열
        if (val) bucket.push(val);
      }
    };
    pick("협력업체 관리대장", types.regular);
    pick("IPC Vendor", types.ipc);
    return types;
  }, { regular: [], ipc: [] });
}

function getDetailData(country, city, vendor) {
  try {
    const ssId = SpreadsheetApp.getActiveSpreadsheet().getId();
    const rawV = SRM_readSheet_('원자재SCM', { id: ssId, ttl: 3600, useDisplay: false });
    const values = rawV.map(r => r.map(v => (v == null ? '' : (typeof v === 'string' ? v : String(v)))));
    if (!values || values.length < 2) return { success: true, headers: [], data: [] };

    const headers = values[0].slice(0, 12);
    const data = [];
    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      if (row[10] === country && row[11] === city && row[9] === vendor) {
        data.push(row.slice(0, 12));
      }
    }
    return { success: true, headers: headers, data: data };
  } catch (e) {
    Logger.log(e.toString());
    return { success: false, message: e.toString() };
  }
}

function getPartnerDetailByCode(vendorCode) {
  try {
    const ss = SpreadsheetApp.openById(PARTNER_DB_ID);

    function isCodeMatched(codeA, codeB) {
      const strA = String(codeA || '').trim();
      const strB = String(codeB || '').trim();
      if (!strA || !strB) return false;
      if (strA.toLowerCase() === strB.toLowerCase()) return true;
      const numA = parseInt(strA, 10), numB = parseInt(strB, 10);
      return (!isNaN(numA) && !isNaN(numB) && numA === numB);
    }

    let sheet = ss.getSheetByName("협력업체 관리대장");
    let matchedRowIdx = -1, lastCol = 0, isIpc = false;

    if (sheet) {
      const lastRow = sheet.getLastRow();
      lastCol = sheet.getLastColumn();
      if (lastRow >= 5) {
        const codes = sheet.getRange(5, 6, lastRow - 4, 1).getDisplayValues();
        for (let i = 0; i < codes.length; i++) {
          if (isCodeMatched(codes[i][0], vendorCode)) { matchedRowIdx = i + 5; break; }
        }
      }
    }
    if (matchedRowIdx === -1) {
      sheet = ss.getSheetByName("IPC Vendor");
      if (sheet) {
        const lastRow = sheet.getLastRow();
        lastCol = sheet.getLastColumn();
        if (lastRow >= 5) {
          const codes = sheet.getRange(5, 6, lastRow - 4, 1).getDisplayValues();
          for (let i = 0; i < codes.length; i++) {
            if (isCodeMatched(codes[i][0], vendorCode)) { matchedRowIdx = i + 5; isIpc = true; break; }
          }
        }
      }
    }
    if (matchedRowIdx === -1) {
      return { success: false, message: `협력업체 코드 '${vendorCode}'에 일치하는 정규협력사 또는 IPC Vendor를 찾을 수 없습니다.` };
    }

    const displayRow = sheet.getRange(matchedRowIdx, 1, 1, lastCol).getDisplayValues()[0];
    const PC_MAP = [
      3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 19, 20, 21, 22, 98, 26, 27, 28, 29, 30,
      31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
      58, 59, 60, 61, 62, 63, 64, 65, 66, 67,
      68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
      78, 79, 80, 81, 82, 83, 84, 85, 86, 87,
      88, 89, 90, 91, 92, 93, 94, 95, 96, 97,
      99, 102, 105, 108,
      111, 112, 113, 114, 115, 116, 117
    ];
    const item = {
      values: PC_MAP.map(c => displayRow[c - 1] || ''),
      isIpc: isIpc,
      lat: displayRow[24 - 1] || '', lon: displayRow[25 - 1] || '',
      factory1Lat: displayRow[100 - 1] || '', factory1Lon: displayRow[101 - 1] || '',
      factory2Lat: displayRow[103 - 1] || '', factory2Lon: displayRow[104 - 1] || '',
      factory3Lat: displayRow[106 - 1] || '', factory3Lon: displayRow[107 - 1] || '',
      factory4Lat: displayRow[109 - 1] || '', factory4Lon: displayRow[110 - 1] || ''
    };
    return { success: true, item: item };
  } catch (e) {
    return { success: false, message: "상세 정보 조회 중 오류가 발생했습니다: " + e.message };
  }
}
