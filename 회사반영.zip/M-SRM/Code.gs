/* =====================================================================
 * M-SRM_Code.gs  ·  메-SRM 메인 포털 백엔드
 * ---------------------------------------------------------------------
 * 공용 로직(include / getUserDetails / fetchUserDeptAndName /
 * checkUserFullAccess / logAccess / getMenuLinks)은 통합_common.gs 로 이관.
 * 이 파일은 포털 고유 로직(뉴스 RSS / 뉴스보관 / 환율 / 덕담)만 담는다.
 * ===================================================================== */

function doGet(e) {
  var template = HtmlService.createTemplateFromFile('index');

  template.srmTheme = (e && e.parameter && (e.parameter.srm_theme || e.parameter.theme)) || '';
  template.randomImageFile = 'image_data1';

  var greetings = getGreetingPool_();
  template.randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
  template.archivedNews = JSON.stringify(getArchivedNews());

  return template.evaluate()
    .setTitle('메-SRM')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/* ---------------------------------------------------------------------
 * 덕담
 * ------------------------------------------------------------------- */
function getGreetingPool_() {
  return [
    '행복 가득한 하루 되세요!',
    '오늘도 힘내세요!',
    '성공적인 하루를 응원합니다.',
    '오늘은 부디 칼퇴하세요!',
    '내일도 부디 칼퇴하세요!',
    '머리아픈 일은 다음에 하세요!',
    '오늘은 이쁜말만 하세요',
    '졸리면 어디가서 자고오세요',
    '주말에는 가족과 함께!'
  ];
}

function getRandomGreeting() {
  var pool = getGreetingPool_();
  return pool[Math.floor(Math.random() * pool.length)];
}

/* ---------------------------------------------------------------------
 * 뉴스 RSS  (개발계획서 §4-2 : 분류 정규식을 모듈 스코프에 1회 컴파일)
 * ------------------------------------------------------------------- */
var NEWS_RE_ITEM     = /<item>([\s\S]*?)<\/item>/g;
var NEWS_RE_PUBDATE  = /<pubDate>([\s\S]*?)<\/pubDate>/;
var NEWS_RE_TITLE    = /<title>([\s\S]*?)<\/title>/;
var NEWS_RE_LINK     = /<link>([\s\S]*?)<\/link>/;
var NEWS_RE_CDATA1   = /<!\[CDATA\[([\s\S]*?)\]\]>/g;
var NEWS_RE_CDATA2   = /&lt;!\[CDATA\[([\s\S]*?)\]\]&gt;/g;
var NEWS_RE_TAGS     = /<\/?[^>]+(>|$)/g;

function buildRssRequest(query, isDomestic) {
  var encodedQuery = encodeURIComponent(query);
  var url = isDomestic
    ? 'https://news.google.com/rss/search?q=' + encodedQuery + '&hl=ko&gl=KR&ceid=KR:ko'
    : 'https://news.google.com/rss/search?q=' + encodedQuery + '&hl=en-US&gl=US&ceid=US:en';
  return { url: url, method: 'get', muteHttpExceptions: true };
}

function parseRssResponse(xml, query) {
  var newsList = [];
  if (!xml) return newsList;

  var oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

  try {
    NEWS_RE_ITEM.lastIndex = 0;
    var itemMatches = xml.match(NEWS_RE_ITEM);
    if (itemMatches) {
      for (var i = 0; i < itemMatches.length; i++) {
        var itemXml = itemMatches[i];
        var pubDateStr = (itemXml.match(NEWS_RE_PUBDATE) || ['', ''])[1];
        var rawDate = new Date(pubDateStr);
        if (rawDate >= oneWeekAgo) {
          var title = (itemXml.match(NEWS_RE_TITLE) || ['', ''])[1]
            .replace(NEWS_RE_CDATA1, '$1')
            .replace(NEWS_RE_CDATA2, '$1')
            .replace(NEWS_RE_TAGS, '');
          var link = (itemXml.match(NEWS_RE_LINK) || ['', '#'])[1];
          newsList.push({ supplier: query, title: title, link: link, pubDate: pubDateStr, rawDate: rawDate });
        }
      }
    }
  } catch (error) {
    Logger.log('정규식 파싱 오류, XmlService 폴백 시도: ' + error.toString());
    try {
      var doc = XmlService.parse(xml);
      var channel = doc.getRootElement().getChild('channel');
      if (channel) {
        var items = channel.getChildren('item');
        for (var j = 0; j < items.length; j++) {
          var pd = items[j].getChildText('pubDate') || new Date().toUTCString();
          var rd = new Date(pd);
          if (rd >= oneWeekAgo) {
            newsList.push({
              supplier: query,
              title: items[j].getChildText('title') || '',
              link: items[j].getChildText('link') || '#',
              pubDate: pd, rawDate: rd
            });
          }
        }
      }
    } catch (xmlErr) {
      Logger.log('XmlService 폴백 실패: ' + xmlErr.toString());
    }
  }

  newsList.sort(function (a, b) { return b.rawDate - a.rawDate; });
  return newsList.slice(0, 10);
}

function saveNewsToArchive(domestic, overseas, updateTimeStr) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName('뉴스보관');
    if (!sheet) {
      sheet = ss.insertSheet('뉴스보관');
      sheet.appendRow(['구분', '협력사', '기사제목', '링크', '발행일', '업데이트일시']);
      sheet.getRange('A1:F1').setBackground('#D3D3D3').setFontWeight('bold');
    }

    var dataArr = [];
    domestic.forEach(function (item) { dataArr.push(['국내', item.supplier, item.title, item.link, item.pubDate, updateTimeStr]); });
    overseas.forEach(function (item) { dataArr.push(['해외', item.supplier, item.title, item.link, item.pubDate, updateTimeStr]); });

    if (sheet.getLastRow() > 1) sheet.getRange(2, 1, sheet.getLastRow() - 1, 6).clearContent();
    if (dataArr.length > 0) sheet.getRange(2, 1, dataArr.length, 6).setValues(dataArr);
  } catch (e) {
    Logger.log('[뉴스보관 오류] ' + e.toString());
  }
}

function getArchivedNews() {
  var result = { domestic: [], overseas: [], lastUpdated: '' };
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName('뉴스보관');
    if (!sheet) return result;

    var lastRow = sheet.getLastRow();
    if (lastRow <= 1) return result;

    var data = sheet.getRange(2, 1, lastRow - 1, 6).getDisplayValues();
    data.forEach(function (row) {
      var type = row[0], supplier = row[1], title = row[2], link = row[3], pubDate = row[4], updateDate = row[5];
      if (!result.lastUpdated && updateDate) result.lastUpdated = updateDate;
      var item = { supplier: supplier, title: title, link: link, pubDate: pubDate };
      if (type === '국내') result.domestic.push(item);
      else if (type === '해외') result.overseas.push(item);
    });
  } catch (e) {
    Logger.log('[아카이브 로드 오류] ' + e.toString());
  }
  return result;
}

function getSupplierNews(forceUpdate) {
  try {
    var cache = CacheService.getScriptCache();
    if (!forceUpdate) {
      var cachedData = cache.get('supplier_news_data');
      if (cachedData) return JSON.parse(cachedData);
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName('뉴스');
    if (!sheet) throw new Error("'뉴스' 시트를 찾을 수 없습니다.");

    var lastRow = sheet.getLastRow();
    if (lastRow <= 1) return { domestic: [], overseas: [], lastUpdated: '' };

    var data = sheet.getRange(2, 1, lastRow - 1, 2).getValues();

    var requests = [], requestMeta = [];
    for (var i = 0; i < data.length; i++) {
      var supplier = String(data[i][0]).trim();
      var regionType = String(data[i][1]).trim();
      if (!supplier) continue;
      var isDomestic = regionType.indexOf('국내') !== -1;
      var isOverseas = regionType.indexOf('해외') !== -1 || regionType.indexOf('국외') !== -1;
      if (isDomestic) { requests.push(buildRssRequest(supplier, true)); requestMeta.push({ supplier: supplier, isDomestic: true }); }
      else if (isOverseas) { requests.push(buildRssRequest(supplier, false)); requestMeta.push({ supplier: supplier, isDomestic: false }); }
    }
    if (requests.length === 0) return { domestic: [], overseas: [], lastUpdated: '' };

    var responses = UrlFetchApp.fetchAll(requests);
    var domestic = [], overseas = [];
    for (var r = 0; r < responses.length; r++) {
      var res = responses[r], meta = requestMeta[r];
      if (res.getResponseCode() === 200) {
        var parsed = parseRssResponse(res.getContentText(), meta.supplier);
        if (meta.isDomestic) domestic = domestic.concat(parsed);
        else overseas = overseas.concat(parsed);
      }
    }
    var sortByDate = function (a, b) { return new Date(b.pubDate) - new Date(a.pubDate); };
    domestic.sort(sortByDate);
    overseas.sort(sortByDate);

    var now = new Date();
    var pad = function (n) { return String(n).padStart(2, '0'); };
    var nowStr = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) +
      ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()) + ':' + pad(now.getSeconds());

    var clean = function (arr) {
      return arr.map(function (it) { return { supplier: it.supplier, title: it.title, link: it.link, pubDate: it.pubDate }; });
    };
    var result = { domestic: clean(domestic), overseas: clean(overseas), lastUpdated: nowStr };
    var jsonString = JSON.stringify(result);

    saveNewsToArchive(domestic, overseas, nowStr);

    try {
      if (jsonString.length < 90000) cache.put('supplier_news_data', jsonString, 1800);
    } catch (cacheError) {
      Logger.log('[뉴스] 캐시 에러 무시: ' + cacheError.toString());
    }
    return result;
  } catch (e) {
    Logger.log('[뉴스 치명적 오류] ' + e.toString());
    throw new Error(e.message || e.toString());
  }
}

/* ---------------------------------------------------------------------
 * 환율
 * ------------------------------------------------------------------- */
function getExchangeRateData() {
  try {
    var ssId = '15mDVNS3jFIX4mNdu0OEHMTaHgDbwvNDSmBp7OxHsH9k';
    var ss = SpreadsheetApp.openById(ssId);
    var sheet = ss.getSheetByName('CurrRaw');
    if (!sheet) return { success: false, message: "'CurrRaw' 시트를 찾을 수 없습니다." };
    return {
      success: true,
      table1: sheet.getRange('C5:G8').getDisplayValues(),
      table2: sheet.getRange('I5:M8').getDisplayValues()
    };
  } catch (e) {
    Logger.log('환율 데이터 로드 오류: ' + e.toString());
    return { success: false, message: e.toString() };
  }
}
